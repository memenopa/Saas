import {Config} from '@remotion/cli/config';

Config.setConcurrency(2);
