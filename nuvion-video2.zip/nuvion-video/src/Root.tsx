import React from 'react';
import {Composition} from 'remotion';
import './lib/fonts';
import {DURATION, FPS, HEIGHT, WIDTH} from './lib/constants';
import {Video} from './Video';

export const Root: React.FC = () => (
  <Composition id="NuvionLaunch" component={Video} durationInFrames={DURATION} fps={FPS} width={WIDTH} height={HEIGHT} defaultProps={{}} />
);
