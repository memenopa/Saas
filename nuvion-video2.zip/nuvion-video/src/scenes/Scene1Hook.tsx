import React from 'react';
import {AbsoluteFill, Easing, interpolate, useCurrentFrame} from 'remotion';
import {Backdrop} from '../components/Backdrop';
import {Camera} from '../components/Camera';
import {Globe} from '../components/Globe';
import {Coin} from '../components/Pill';
import {Row, Word} from '../components/Word';
import {Sparkle} from '../components/Sparkle';
import {C, CURRENCIES, FPS, SCENES, sec} from '../lib/constants';
import {clampOpts, pop, ramp} from '../lib/motion';

const S = SCENES.hook.from;
const L = (a: number) => sec(a - S);

export const Scene1Hook: React.FC = () => {
  const frame = useCurrentFrame();
  const globeIn = pop(frame, 0);
  const rot = frame * 0.03;
  const grow = 1 + ramp(frame, L(1.84), L(2.6), 0, 0.14);

  // Sparkle portal: pop in, spin, then exponential scale to fill the frame.
  const spIn = pop(frame, L(2.9));
  const g0 = L(3.1);
  const g1 = L(3.49);
  const grown = interpolate(frame, [g0, g1], [0, Math.log(85)], {...clampOpts, easing: Easing.in(Easing.quad)});
  const spScale = spIn * Math.exp(grown);
  const spRot = frame * 4 + ramp(frame, g0, g1, 0, 180);
  const overlay = ramp(frame, L(3.28), L(3.47));

  return (
    <AbsoluteFill>
      <Backdrop mode="light" />
      <Camera zoom={0.05}>
        <div style={{position: 'absolute', left: 960 - 410, top: 600 - 410, transform: `scale(${globeIn * grow}) rotate(-12deg)`}}>
          <Globe size={820} rot={rot} opacity={0.38} pulse={frame} />
        </div>
        {CURRENCIES.map((g, i) => {
          const a = frame * 0.045 + (i * Math.PI * 2) / CURRENCIES.length;
          const x = 960 + Math.cos(a) * 560;
          const y = 600 + Math.sin(a) * 210;
          const depth = 0.75 + 0.25 * ((Math.sin(a) + 1) / 2);
          return (
            <div key={g} style={{position: 'absolute', left: x - 50, top: y - 50, transform: `scale(${depth * globeIn})`, zIndex: Math.round(depth * 10)}}>
              <Coin glyph={g} size={100} />
            </div>
          );
        })}

        {/* Line 1 */}
        <div style={{position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 0}}>
          <Row gap={34}>
            <Word at={L(0.02)} exitAt={L(1.5)} size={124}>The</Word>
            <Word at={L(0.2)} exitAt={L(1.5)} size={124}>world</Word>
            <Word at={L(0.42)} exitAt={L(1.5)} size={124}>is</Word>
          </Row>
          <Word at={L(0.62)} exitAt={L(1.52)} size={270} grad>global.</Word>
        </div>

        {/* Line 2 */}
        <div style={{position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center'}}>
          <Row gap={34}>
            <Word at={L(1.84)} size={150}>Your</Word>
            <Word at={L(2.02)} size={150}>money</Word>
          </Row>
          <Row gap={34}>
            <Word at={L(2.28)} size={150}>should</Word>
            <Word at={L(2.5)} size={150}>be</Word>
            <Word at={L(2.68)} size={150} grad>too.</Word>
            <div style={{position: 'relative', width: 90, height: 90, alignSelf: 'center', marginLeft: 6}}>
              <Sparkle size={90} rotate={spRot} scale={spScale} fill={C.night} style={{position: 'absolute', inset: 0}} />
            </div>
          </Row>
        </div>
      </Camera>
      <AbsoluteFill style={{background: C.night, opacity: overlay}} />
    </AbsoluteFill>
  );
};
