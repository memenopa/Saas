import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {Backdrop} from '../components/Backdrop';
import {Camera} from '../components/Camera';
import {Globe} from '../components/Globe';
import {glass} from '../components/Pill';
import {Word} from '../components/Word';
import {C, FONT_BODY, FONT_HEAD, GRAD, SCENES} from '../lib/constants';
import {local, pop, ramp, SNAPPY} from '../lib/motion';

const S = SCENES.pay.from;
const L = (a: number) => local(a, S);

const NOTES = [
  {g: '₦', amt: '+₦ 385,000', city: 'Lagos · Naira'},
  {g: '€', amt: '+€ 1,180.00', city: 'Berlin · Euro'},
  {g: '£', amt: '+£ 86.40', city: 'London · Pound'},
  {g: '¥', amt: '+¥ 12,400', city: 'Tokyo · Yen'},
  {g: '$', amt: '+$ 240.00', city: 'New York · Dollar'},
];

export const Scene5Pay: React.FC = () => {
  const frame = useCurrentFrame();
  const tiltX = 8 + Math.sin(frame / 14) * 2;
  const tiltY = -16 + frame * 0.12;
  const count = Math.round(ramp(frame, 4, 58, 0, 2481));
  return (
    <AbsoluteFill>
      <Backdrop mode="light" />
      <Camera zoom={0.06} amp={1.1}>
        <div style={{position: 'absolute', left: 1180 - 380, top: 540 - 380, transform: 'rotate(12deg)'}}>
          <Globe size={760} rot={frame * 0.05} opacity={0.3} pulse={frame} />
        </div>

        <div style={{position: 'absolute', left: 130, top: 250, display: 'flex', flexDirection: 'column'}}>
          <Word at={L(12.12)} size={150}>Accept</Word>
          <Word at={L(12.5)} size={150}>payments</Word>
          <Word at={L(13.0)} size={150} grad>worldwide.</Word>
        </div>

        <div style={{position: 'absolute', left: 1020, top: 170, width: 780, transform: `perspective(1400px) rotateX(${tiltX}deg) rotateY(${tiltY}deg)`, transformStyle: 'preserve-3d'}}>
          <div style={{...glass('light'), borderRadius: 28, padding: '18px 28px', marginBottom: 26, display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', transform: `scale(${pop(frame, 2)})`}}>
            <span style={{fontFamily: FONT_BODY, fontWeight: 600, fontSize: 28, color: C.inkSoft}}>Payments accepted</span>
            <span style={{fontFamily: FONT_HEAD, fontWeight: 800, fontSize: 64, color: C.ink, letterSpacing: '-0.03em'}}>{count.toLocaleString('en-US')}</span>
          </div>
          {NOTES.map((n, i) => {
            const p = pop(frame, 6 + i * 8, SNAPPY);
            return (
              <div
                key={i}
                style={{
                  ...glass('light'),
                  borderRadius: 30,
                  padding: '18px 26px',
                  marginBottom: 20,
                  display: 'flex',
                  alignItems: 'center',
                  gap: 22,
                  opacity: Math.min(1, p * 2),
                  transform: `translateX(${(1 - p) * 420}px) translateZ(${i * 8}px)`,
                }}
              >
                <div style={{width: 72, height: 72, borderRadius: 24, background: GRAD, color: '#fff', fontFamily: FONT_BODY, fontWeight: 700, fontSize: 40, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
                  {n.g}
                </div>
                <div style={{flex: 1}}>
                  <div style={{fontFamily: FONT_BODY, fontWeight: 700, fontSize: 30, color: C.ink}}>Payment received</div>
                  <div style={{fontFamily: FONT_BODY, fontWeight: 500, fontSize: 24, color: C.inkSoft}}>{n.city}</div>
                </div>
                <div style={{fontFamily: FONT_HEAD, fontWeight: 800, fontSize: 38, color: C.ink}}>{n.amt}</div>
                <div style={{width: 40, height: 40, borderRadius: '50%', background: C.mint, display: 'flex', alignItems: 'center', justifyContent: 'center', transform: `scale(${pop(frame, 10 + i * 8)})`}}>
                  <svg width={22} height={22} viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth={3.5} strokeLinecap="round" strokeLinejoin="round"><path d="M5 12l5 5 9-10" /></svg>
                </div>
              </div>
            );
          })}
        </div>
      </Camera>
    </AbsoluteFill>
  );
};
