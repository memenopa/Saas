import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {Backdrop} from '../components/Backdrop';
import {Camera} from '../components/Camera';
import {Globe} from '../components/Globe';
import {Row, Word} from '../components/Word';
import {C, SCENES} from '../lib/constants';
import {local, mod} from '../lib/motion';

const S = SCENES.limits.from;
const L = (a: number) => local(a, S);
const RINGS = 9;
const STREAKS = 28;

export const Scene9Limits: React.FC = () => {
  const frame = useCurrentFrame();
  return (
    <AbsoluteFill>
      <Backdrop mode="light" />
      <Camera zoom={0.04} amp={0.6}>
        <svg width={1920} height={1080} style={{position: 'absolute', inset: 0}}>
          {new Array(STREAKS).fill(0).map((_, i) => {
            const a = (i / STREAKS) * Math.PI * 2 + 0.1;
            const ph = mod(frame * 0.02 + (i % 7) / 7, 1);
            const r1 = 80 + ph * ph * 1500;
            const r2 = r1 + 40 + ph * 260;
            return (
              <line
                key={i}
                x1={960 + Math.cos(a) * r1}
                y1={540 + Math.sin(a) * r1}
                x2={960 + Math.cos(a) * r2}
                y2={540 + Math.sin(a) * r2}
                stroke={i % 3 ? C.coral : C.ember}
                strokeWidth={2 + ph * 5}
                strokeLinecap="round"
                opacity={Math.sin(Math.PI * ph) * 0.55}
              />
            );
          })}
          {new Array(RINGS).fill(0).map((_, i) => {
            const d = mod(frame * 0.012 + i / RINGS, 1);
            const r = 60 * Math.exp(d * 3.9);
            return (
              <circle
                key={i}
                cx={960}
                cy={540}
                r={r}
                fill="none"
                stroke={C.ember}
                strokeWidth={2 + d * 7}
                strokeDasharray={`${20 + d * 60} ${24 + d * 50}`}
                strokeDashoffset={-frame * (3 + i)}
                opacity={Math.sin(Math.PI * d) * 0.55}
              />
            );
          })}
        </svg>
        <div style={{position: 'absolute', left: 960 - 160, top: 540 - 160, opacity: 0.35}}>
          <Globe size={320} rot={frame * 0.08} opacity={0.6} pulse={frame} />
        </div>
        <div style={{position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center'}}>
          <Row gap={30}>
            <Word at={L(22.05)} size={132}>Built</Word>
            <Word at={L(22.35)} size={132}>for</Word>
            <Word at={L(22.5)} size={132}>a</Word>
            <Word at={L(22.7)} size={132}>world</Word>
          </Row>
          <Row gap={34}>
            <Word at={L(23.1)} size={200} grad>without</Word>
            <Word at={L(23.5)} size={200} grad>limits.</Word>
          </Row>
        </div>
      </Camera>
    </AbsoluteFill>
  );
};
