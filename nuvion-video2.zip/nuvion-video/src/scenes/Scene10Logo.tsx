import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {Backdrop} from '../components/Backdrop';
import {Camera} from '../components/Camera';
import {Logo} from '../components/Logo';
import {Sparkle} from '../components/Sparkle';
import {C} from '../lib/constants';
import {pop, ramp} from '../lib/motion';

export const Scene10Logo: React.FC = () => {
  const frame = useCurrentFrame();
  const p = pop(frame, 1);
  const shimmer = ramp(frame, 6, 30, 0, 1);
  return (
    <AbsoluteFill>
      <Backdrop mode="dark" particles={34} />
      <Camera zoom={0.1} amp={1}>
        {[0, 1, 2].map((i) => {
          const ph = ((frame - i * 5) / 28);
          if (ph < 0) return null;
          return <div key={i} style={{position: 'absolute', left: 960 - 500, top: 540 - 500, width: 1000, height: 1000, borderRadius: '50%', border: `4px solid ${C.ember}`, opacity: Math.max(0, 1 - ph) * 0.7, transform: `scale(${0.2 + ph * 2.2})`}} />;
        })}
        {[0, 1, 2, 3, 4, 5].map((i) => {
          const a = i * 1.05 + 0.4;
          const dist = 360 + ramp(frame, 0, 24, 0, 260) + i * 14;
          return (
            <div key={i} style={{position: 'absolute', left: 960 + Math.cos(a) * dist - 30, top: 540 + Math.sin(a) * dist * 0.5 - 30, opacity: ramp(frame, 2, 8) * (1 - ramp(frame, 20, 34))}}>
              <Sparkle size={60} rotate={frame * 6 + i * 30} fill={C.peach} />
            </div>
          );
        })}
        <div style={{position: 'absolute', left: 960 - 640, top: 540 - 1280 / 5.09 / 2, width: 1280, transform: `scale(${1.35 - p * 0.35})`, opacity: p, filter: `blur(${(1 - p) * 16}px)`}}>
          <Logo width={1280} variant="light" shimmer={shimmer} />
        </div>
      </Camera>
    </AbsoluteFill>
  );
};
