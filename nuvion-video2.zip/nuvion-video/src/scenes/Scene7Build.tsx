import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {Backdrop} from '../components/Backdrop';
import {Camera} from '../components/Camera';
import {Confetti} from '../components/Confetti';
import {Cursor} from '../components/Cursor';
import {Dashboard} from '../components/Dashboard';
import {IconKind, NavPill} from '../components/Pill';
import {Row, Word} from '../components/Word';
import {C, FONT_BODY, FONT_HEAD, GRAD, SCENES} from '../lib/constants';
import {local, pop, ramp, SMOOTH, SNAPPY} from '../lib/motion';

const S = SCENES.build.from;
const L = (a: number) => local(a, S);
const BX = 1285; // button / progress centre
const BY = 975;
const CARDS: {label: string; kind: IconKind; dx: number; dy: number}[] = [
  {label: 'Accounts', kind: 'accounts', dx: -260, dy: -480},
  {label: 'Payments', kind: 'payments', dx: 260, dy: -480},
  {label: 'Payouts', kind: 'payouts', dx: -260, dy: -240},
  {label: 'Cards', kind: 'cards', dx: 260, dy: -240},
];

export const Scene7Build: React.FC = () => {
  const frame = useCurrentFrame();
  const dashIn = pop(frame, 4, SMOOTH);
  const rotX = 22 - 14 * dashIn + Math.sin(frame / 18) * 1.5;
  const rotY = -15 + 11 * dashIn + Math.cos(frame / 22) * 1.5;
  const fan = pop(frame, L(17.05), SNAPPY);
  const dim = ramp(frame, L(17.05), L(17.4));

  // button press (scale 1 -> .92 -> 1.04 -> 1) at click time
  const click = L(17.0);
  const press = frame < click ? 1 : frame < click + 3 ? 0.92 : frame < click + 7 ? 1.04 : 1;
  const morph = pop(frame, L(17.45), SMOOTH);
  const prog = ramp(frame, L(17.6), L(19.3), 0, 100);
  const done = frame >= L(19.35);
  const btnW = 300 + morph * 640;

  // cursor path: from bottom-right to the button
  const cp = ramp(frame, L(16.2), L(16.95));
  const cx = 1760 + (BX - 1760) * cp;
  const cy = 1060 + (BY - 1060) * cp - Math.sin(cp * Math.PI) * 120;
  const cursorOut = ramp(frame, L(17.1), L(17.5));

  const phase1Out = L(17.3);
  return (
    <AbsoluteFill>
      <Backdrop mode="light" />
      <Camera zoom={0.05} amp={0.8}>
        {/* headline: two phases */}
        <div style={{position: 'absolute', left: 120, top: 60}}>
          <Row gap={26} align="flex-start">
            <Word at={L(15.5)} exitAt={phase1Out} size={96}>And</Word>
            <Word at={L(15.7)} exitAt={phase1Out} size={96}>build</Word>
            <Word at={L(16.05)} exitAt={phase1Out} size={96}>financial</Word>
          </Row>
          <div style={{marginTop: -6}}>
            <Word at={L(16.5)} exitAt={phase1Out} size={130} grad>experiences</Word>
          </div>
        </div>
        <div style={{position: 'absolute', left: 120, top: 60}}>
          <Row gap={26} align="flex-start">
            <Word at={L(17.6)} size={96}>with</Word>
            <Word at={L(17.9)} size={96}>infrastructure</Word>
          </Row>
          <div style={{marginTop: -6}}>
            <Word at={L(18.5)} size={130} grad>designed to scale.</Word>
          </div>
        </div>

        {/* 2.5D dashboard */}
        <div
          style={{
            position: 'absolute',
            left: 760,
            top: 300,
            transform: `perspective(1400px) rotateX(${rotX}deg) rotateY(${rotY}deg) rotateZ(${-3 + 3 * dashIn}deg) translateY(${(1 - dashIn) * 420}px) scale(${0.9 + dashIn * 0.1})`,
            opacity: Math.min(1, dashIn * 2) * (1 - dim * 0.45),
            filter: `blur(${dim * 2.5}px)`,
          }}
        >
          <Dashboard />
        </div>

        {/* fan-out clone cards */}
        {CARDS.map((c, i) => (
          <div
            key={c.label}
            style={{
              position: 'absolute',
              left: BX - 190 + c.dx * fan,
              top: BY - 56 + c.dy * fan,
              opacity: Math.min(1, fan * 2),
              transform: `scale(${0.3 + fan * 0.7}) rotate(${(1 - fan) * (i % 2 ? 14 : -14)}deg)`,
              zIndex: 20,
            }}
          >
            <NavPill label={c.label} kind={c.kind} width={380} />
          </div>
        ))}

        {/* button -> progress morph */}
        <div
          style={{
            position: 'absolute',
            left: BX - btnW / 2,
            top: BY - 46,
            width: btnW,
            height: 92,
            borderRadius: 999,
            background: done ? C.mint : morph > 0.5 ? 'rgba(255,255,255,0.85)' : GRAD,
            boxShadow: '0 18px 44px rgba(255,90,54,0.45), inset 0 3px 0 rgba(255,255,255,0.5)',
            transform: `scale(${press * pop(frame, L(16.3))})`,
            overflow: 'hidden',
            zIndex: 30,
          }}
        >
          {morph > 0.5 && !done && (
            <div style={{position: 'absolute', left: 0, top: 0, bottom: 0, width: `${prog}%`, background: GRAD}} />
          )}
          <div style={{position: 'relative', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: FONT_HEAD, fontWeight: 800, fontSize: 40, color: morph > 0.5 && !done ? C.ink : '#fff', letterSpacing: '-0.02em', gap: 14}}>
            {done ? 'Done ✓' : morph > 0.5 ? <><span style={{fontFamily: FONT_BODY, fontWeight: 600, fontSize: 30}}>Scaling</span>{Math.round(prog)}%</> : '＋ New account'}
          </div>
        </div>
        <Confetti at={L(19.35)} x={BX} y={BY} />
        <div style={{opacity: 1 - cursorOut, display: frame < L(16.2) ? 'none' : 'block'}}>
          <Cursor x={cx} y={cy} scale={press < 1 ? 0.9 : 1} />
        </div>
      </Camera>
    </AbsoluteFill>
  );
};
