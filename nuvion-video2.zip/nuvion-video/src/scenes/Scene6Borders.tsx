import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {Backdrop} from '../components/Backdrop';
import {Camera} from '../components/Camera';
import {Coin} from '../components/Pill';
import {Row, Word} from '../components/Word';
import {C, SCENES} from '../lib/constants';
import {local, pop} from '../lib/motion';

const S = SCENES.borders.from;
const L = (a: number) => local(a, S);
const X0 = 380;
const X1 = 1540;
const PERIOD = 20;

export const Scene6Borders: React.FC = () => {
  const frame = useCurrentFrame();
  const intro = pop(frame, 0);
  const lastCross = Math.floor((frame - 10) / PERIOD);
  return (
    <AbsoluteFill>
      <Backdrop mode="dark" />
      <Camera zoom={0.08} amp={1.3}>
        {/* border line */}
        <div style={{position: 'absolute', left: 958, top: 120 * intro, width: 4, height: 620, background: `linear-gradient(${C.ember}, ${C.peach})`, boxShadow: `0 0 40px ${C.ember}`, opacity: 0.55 + 0.35 * Math.sin(frame / 3)}} />

        <div style={{position: 'absolute', left: X0 - 90, top: 430 - 90, transform: `scale(${intro})`}}>
          <Coin glyph="$" size={180} dark />
        </div>
        <div style={{position: 'absolute', left: X1 - 90, top: 430 - 90, transform: `scale(${intro})`}}>
          <Coin glyph="€" size={180} dark />
        </div>

        {/* packets crossing the border */}
        {new Array(6).fill(0).map((_, i) => {
          const f = frame - 8 - i * (PERIOD / 2);
          if (f < 0) return null;
          const u = (f % PERIOD) / PERIOD;
          const x = X0 + (X1 - X0) * u;
          const y = 430 - 190 * Math.sin(Math.PI * u) - 20;
          const glyph = u < 0.5 ? '$' : '€';
          return (
            <React.Fragment key={i}>
              {[1, 2, 3].map((t) => {
                const uu = Math.max(0, u - t * 0.03);
                return (
                  <div key={t} style={{position: 'absolute', left: X0 + (X1 - X0) * uu - 12, top: 430 - 190 * Math.sin(Math.PI * uu) - 32, width: 24, height: 24, borderRadius: '50%', background: C.coral, opacity: 0.35 / t}} />
                );
              })}
              <div style={{position: 'absolute', left: x - 42, top: y - 42, zIndex: 8}}>
                <Coin glyph={glyph} size={84} />
              </div>
            </React.Fragment>
          );
        })}

        {/* shock ring at the border each crossing */}
        {(() => {
          const ph = ((frame - 8) % (PERIOD / 2)) / (PERIOD / 2);
          return <div style={{position: 'absolute', left: 960 - 160, top: 60, width: 320, height: 320, borderRadius: '50%', border: `3px solid ${C.ember}`, opacity: lastCross >= 0 ? (1 - ph) * 0.7 : 0, transform: `scale(${0.3 + ph})`}} />;
        })()}

        <div style={{position: 'absolute', left: 0, right: 0, top: 650, display: 'flex', flexDirection: 'column', alignItems: 'center'}}>
          <Row gap={34}>
            <Word at={L(14.1)} size={110} color={C.blush}>Pay</Word>
            <Word at={L(14.4)} size={110} color={C.blush}>across</Word>
          </Row>
          <Word at={L(14.75)} size={170} grad style={{marginTop: -10}}>borders.</Word>
        </div>
      </Camera>
    </AbsoluteFill>
  );
};
