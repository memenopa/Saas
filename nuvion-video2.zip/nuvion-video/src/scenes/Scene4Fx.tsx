import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {Backdrop} from '../components/Backdrop';
import {Camera} from '../components/Camera';
import {Coin, glass} from '../components/Pill';
import {Row, Word} from '../components/Word';
import {C, CURRENCIES, FONT_BODY, SCENES} from '../lib/constants';
import {local, pop} from '../lib/motion';

const S = SCENES.fx.from;
const L = (a: number) => local(a, S);
const PAIRS = ['USD → EUR', 'EUR → GBP', 'GBP → NGN', 'NGN → JPY', 'JPY → USD'];

export const Scene4Fx: React.FC = () => {
  const frame = useCurrentFrame();
  const intro = pop(frame, 0);
  const th = frame * 0.14;
  const cx = 960;
  const cy = 400;
  const pair = PAIRS[Math.floor(frame / 11) % PAIRS.length];

  const coin = (phase: number, k: number) => {
    const a = th + phase;
    const x = cx + Math.cos(a) * 340;
    const y = cy + Math.sin(a) * 80;
    const flip = a * 2;
    const glyph = CURRENCIES[(Math.floor(flip / Math.PI) + k + 50) % CURRENCIES.length];
    const depth = 0.8 + 0.3 * ((Math.sin(a) + 1) / 2);
    return (
      <div key={k} style={{position: 'absolute', left: x - 110, top: y - 110, transform: `scale(${depth * intro})`, zIndex: Math.round(depth * 10)}}>
        <Coin glyph={glyph} size={220} scaleX={Math.max(0.12, Math.abs(Math.cos(flip)))} dark />
      </div>
    );
  };

  return (
    <AbsoluteFill>
      <Backdrop mode="dark" />
      <Camera zoom={0.07} amp={1.1}>
        <svg width={1920} height={1080} style={{position: 'absolute', inset: 0}}>
          <ellipse cx={cx} cy={cy} rx={340} ry={80} fill="none" stroke={C.ember} strokeWidth={4} strokeDasharray="16 20" strokeDashoffset={-frame * 7} opacity={0.8} />
          <ellipse cx={cx} cy={cy} rx={440} ry={130} fill="none" stroke={C.coral} strokeWidth={2} strokeDasharray="6 22" strokeDashoffset={frame * 5} opacity={0.4} />
        </svg>
        {coin(0, 0)}
        {coin(Math.PI, 1)}
        <div style={{position: 'absolute', left: 960 - 170, top: 560, width: 340, textAlign: 'center', ...glass('dark'), borderRadius: 999, padding: '14px 0', fontFamily: FONT_BODY, fontWeight: 700, fontSize: 38, color: C.peach, transform: `scale(${intro})`}}>
          {pair}
        </div>
        <div style={{position: 'absolute', left: 0, right: 0, top: 690, display: 'flex', flexDirection: 'column', alignItems: 'center'}}>
          <Row gap={30}>
            <Word at={L(10.5)} size={96} color={C.blush}>Move</Word>
            <Word at={L(10.85)} size={96} color={C.blush}>between</Word>
          </Row>
          <Word at={L(11.25)} size={170} grad>currencies.</Word>
        </div>
      </Camera>
    </AbsoluteFill>
  );
};
