import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {Backdrop} from '../components/Backdrop';
import {Camera} from '../components/Camera';
import {Globe} from '../components/Globe';
import {Logo} from '../components/Logo';
import {Coin} from '../components/Pill';
import {Row, Word} from '../components/Word';
import {Sparkle} from '../components/Sparkle';
import {C, CURRENCIES, FONT_BODY, GRAD, SCENES} from '../lib/constants';
import {local, pop} from '../lib/motion';

const S = SCENES.tag.from;
const L = (a: number) => local(a, S);

export const Scene11Tag: React.FC = () => {
  const frame = useCurrentFrame();
  const logoP = pop(frame, 2);
  const urlP = pop(frame, L(26.0));
  return (
    <AbsoluteFill>
      <Backdrop mode="light" particles={34} />
      <Camera zoom={0.1} amp={1}>
        <div style={{position: 'absolute', left: 960 - 560, top: 560 - 560, opacity: 0.28}}>
          <Globe size={1120} rot={frame * 0.025} opacity={0.5} pulse={frame} />
        </div>
        {CURRENCIES.map((g, i) => {
          const a = frame * 0.03 + (i * Math.PI * 2) / CURRENCIES.length;
          return (
            <div key={g} style={{position: 'absolute', left: 960 + Math.cos(a) * 780 - 40, top: 540 + Math.sin(a) * 330 - 40, opacity: 0.9}}>
              <Coin glyph={g} size={80} />
            </div>
          );
        })}
        {[0, 1, 2].map((i) => (
          <div key={i} style={{position: 'absolute', left: [220, 1620, 1500][i], top: [200, 260, 800][i], opacity: 0.5 + 0.5 * Math.sin(frame / 5 + i * 2)}}>
            <Sparkle size={[70, 54, 80][i]} rotate={frame * 3 * (i % 2 ? -1 : 1)} grad />
          </div>
        ))}
        <div style={{position: 'absolute', left: 960 - 190, top: 110, transform: `scale(${logoP})`, opacity: logoP}}>
          <Logo width={380} variant="dark" />
        </div>
        <div style={{position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', paddingTop: 20}}>
          <Row gap={44}>
            <Word at={L(25.38)} size={220}>Go</Word>
            <Word at={L(25.62)} size={220} grad>borderless.</Word>
          </Row>
        </div>
        <div style={{position: 'absolute', left: 0, right: 0, top: 800, display: 'flex', justifyContent: 'center', transform: `scale(${urlP})`, opacity: urlP}}>
          <div style={{background: GRAD, color: '#fff', fontFamily: FONT_BODY, fontWeight: 700, fontSize: 48, padding: '22px 56px', borderRadius: 999, boxShadow: '0 20px 50px rgba(255,90,54,0.4), inset 0 3px 0 rgba(255,255,255,0.5)', letterSpacing: '-0.01em'}}>
            nuvion.co
          </div>
        </div>
      </Camera>
    </AbsoluteFill>
  );
};
