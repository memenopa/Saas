import {Easing, interpolate, spring} from 'remotion';
import {FPS} from './constants';

export const SNAPPY = {damping: 16, stiffness: 140, mass: 0.8};
export const SMOOTH = {damping: 200};
export const SOFT = {damping: 18, stiffness: 90, mass: 1};

export const clampOpts = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;

export const pop = (frame: number, delay = 0, config: Partial<typeof SNAPPY> = SNAPPY) =>
  spring({frame: Math.max(0, frame - delay), fps: FPS, config});

export const ramp = (
  frame: number,
  from: number,
  to: number,
  a = 0,
  b = 1,
  easing: (t: number) => number = Easing.out(Easing.cubic)
) => interpolate(frame, [from, to], [a, b], {...clampOpts, easing});

/** absolute seconds -> frame local to a scene that starts at `start` seconds */
export const local = (abs: number, start: number) => Math.round((abs - start) * FPS);

export const mod = (v: number, m: number) => ((v % m) + m) % m;
