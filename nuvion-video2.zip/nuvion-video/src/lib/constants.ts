export const FPS = 30; // set to 60 for ultra-smooth motion (all timings are in seconds)
export const WIDTH = 1920;
export const HEIGHT = 1080;
export const VO_SECONDS = 26.436;
export const TOTAL_SECONDS = 27.5;
export const DURATION = Math.round(TOTAL_SECONDS * FPS);
export const OVERLAP = Math.round(0.35 * FPS); // frames a scene stays alive under the next one

export const sec = (s: number) => Math.round(s * FPS);

// Brand palette, sampled from the Nuvion wordmark (ink #2A0703 on blush #FAEFEB) plus warm accents.
export const C = {
  ink: '#2A0703',
  inkSoft: '#6B3A31',
  blush: '#FAEFEB',
  blushDeep: '#F6DDD4',
  white: '#FFFFFF',
  ember: '#FF5A36',
  coral: '#FF8A63',
  peach: '#FFC2A8',
  mint: '#2FD6A1',
  night: '#150403',
  night2: '#2A0703',
};

export const GRAD = `linear-gradient(100deg, ${C.ember} 0%, ${C.coral} 55%, #FFB38F 100%)`;
export const FONT_HEAD = "'Nuvion Sans', 'Outfit', system-ui, sans-serif";
export const FONT_BODY = "'Inter', system-ui, sans-serif";

export type Win = {from: number; to: number};

// Scene windows in seconds, aligned to the pauses in the voiceover.
export type SceneKey = 'hook' | 'meet' | 'eco' | 'fx' | 'pay' | 'borders' | 'build' | 'ai' | 'limits' | 'logo' | 'tag';
export const SCENES: Record<SceneKey, Win> = {
  hook: {from: 0, to: 3.49},
  meet: {from: 3.49, to: 4.91},
  eco: {from: 4.91, to: 10.47},
  fx: {from: 10.47, to: 12.08},
  pay: {from: 12.08, to: 14.09},
  borders: {from: 14.09, to: 15.44},
  build: {from: 15.44, to: 19.83},
  ai: {from: 19.83, to: 22.01},
  limits: {from: 22.01, to: 24.36},
  logo: {from: 24.36, to: 25.35},
  tag: {from: 25.35, to: TOTAL_SECONDS},
};

export const CURRENCIES = ['$', '€', '£', '¥', '₦'];
