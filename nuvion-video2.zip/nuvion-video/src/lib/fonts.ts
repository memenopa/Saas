import {loadFont as loadOutfit} from '@remotion/google-fonts/Outfit';
import {loadFont as loadInter} from '@remotion/google-fonts/Inter';
import {continueRender, delayRender, staticFile} from 'remotion';

loadOutfit('normal', {weights: ['700', '800'], subsets: ['latin']});
loadInter('normal', {weights: ['500', '600', '700'], subsets: ['latin']});

// Optional: real "Nuvion Sans" file placed in public/fonts/. Silently skipped if missing.
const handle = delayRender('Loading Nuvion Sans (optional)');
const face = new FontFace(
  'Nuvion Sans',
  `url(${staticFile('fonts/NuvionSans.woff2')}) format('woff2'), url(${staticFile(
    'fonts/NuvionSans.otf'
  )}) format('opentype'), url(${staticFile('fonts/NuvionSans.ttf')}) format('truetype')`,
  {weight: '700 900'}
);
face
  .load()
  .then((f) => document.fonts.add(f))
  .catch(() => undefined)
  .finally(() => continueRender(handle));
