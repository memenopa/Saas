import React from 'react';
import {C} from '../lib/constants';

const CITIES: [number, number][] = [
  [6.5, 3.4],
  [51.5, -0.1],
  [40.7, -74],
  [-23.5, -46.6],
  [25.2, 55.3],
  [1.35, 103.8],
  [35.7, 139.7],
  [-33.9, 151.2],
];

/** Rotating wireframe globe with pulsing city hubs. `rot` in radians. */
export const Globe: React.FC<{
  size: number;
  rot: number;
  stroke?: string;
  opacity?: number;
  pulse?: number;
}> = ({size, rot, stroke = C.ember, opacity = 0.5, pulse = 0}) => {
  const R = size / 2;
  const meridians = new Array(8).fill(0).map((_, i) => Math.abs(Math.cos(rot + (i * Math.PI) / 8)) * R);
  const lats = [-60, -30, 0, 30, 60];
  return (
    <svg width={size} height={size} viewBox={`${-R} ${-R} ${size} ${size}`} style={{overflow: 'visible'}}>
      <circle r={R} fill="none" stroke={stroke} strokeWidth={3} opacity={opacity} />
      {meridians.map((rx, i) => (
        <ellipse key={`m${i}`} rx={rx} ry={R} fill="none" stroke={stroke} strokeWidth={2} opacity={opacity * 0.7} />
      ))}
      {lats.map((l) => {
        const a = (l * Math.PI) / 180;
        return (
          <ellipse
            key={`l${l}`}
            cy={R * Math.sin(a)}
            rx={R * Math.cos(a)}
            ry={R * Math.cos(a) * 0.16}
            fill="none"
            stroke={stroke}
            strokeWidth={2}
            opacity={opacity * 0.7}
          />
        );
      })}
      {CITIES.map(([lat, lon], i) => {
        const la = (lat * Math.PI) / 180;
        const lo = (lon * Math.PI) / 180 + rot;
        const z = Math.cos(la) * Math.cos(lo);
        if (z <= 0.05) return null;
        const x = R * Math.cos(la) * Math.sin(lo);
        const y = -R * Math.sin(la);
        const ph = (pulse / 30 + i * 0.37) % 1;
        return (
          <g key={`c${i}`} opacity={Math.min(1, z * 2.2)}>
            <circle cx={x} cy={y} r={10 + ph * 34} fill="none" stroke={C.ember} strokeWidth={3} opacity={(1 - ph) * 0.8} />
            <circle cx={x} cy={y} r={9} fill={C.ember} />
          </g>
        );
      })}
    </svg>
  );
};
