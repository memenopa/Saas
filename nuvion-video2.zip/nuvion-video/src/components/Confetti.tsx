import React from 'react';
import {random, useCurrentFrame} from 'remotion';
import {C} from '../lib/constants';

const COLORS = [C.ember, C.coral, C.peach, C.mint, C.ink];

/** 2D confetti burst starting at local frame `at`, origin (x, y). Deterministic. */
export const Confetti: React.FC<{at: number; x: number; y: number; count?: number}> = ({at, x, y, count = 34}) => {
  const frame = useCurrentFrame();
  const f = frame - at;
  if (f < 0) return null;
  return (
    <>
      {new Array(count).fill(0).map((_, i) => {
        const a = random(`ca${i}`) * Math.PI * 2;
        const v = 14 + random(`cv${i}`) * 22;
        const px = x + Math.cos(a) * v * f * 0.9;
        const py = y + Math.sin(a) * v * f * 0.9 + 0.9 * f * f * 0.5;
        const op = Math.max(0, 1 - f / 40);
        return (
          <div
            key={i}
            style={{
              position: 'absolute',
              left: px,
              top: py,
              width: 16,
              height: 10 + (i % 3) * 4,
              background: COLORS[i % COLORS.length],
              borderRadius: 3,
              opacity: op,
              transform: `rotate(${f * (8 + (i % 5) * 4)}deg)`,
              zIndex: 60,
            }}
          />
        );
      })}
    </>
  );
};
