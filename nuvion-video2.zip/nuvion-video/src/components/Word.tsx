import React from 'react';
import {useCurrentFrame} from 'remotion';
import {C, FONT_HEAD, GRAD} from '../lib/constants';
import {ramp} from '../lib/motion';

/** Directional blur word swap: opacity + translate + blur, in and (optionally) out. */
export const Word: React.FC<{
  children: React.ReactNode;
  at: number; // local frame the word enters
  exitAt?: number; // local frame the word leaves
  size?: number;
  grad?: boolean;
  color?: string;
  weight?: number;
  font?: string;
  spacing?: string;
  dx?: number;
  style?: React.CSSProperties;
}> = ({
  children,
  at,
  exitAt,
  size = 110,
  grad = false,
  color = C.ink,
  weight = 800,
  font = FONT_HEAD,
  spacing = '-0.035em',
  dx = 0,
  style,
}) => {
  const frame = useCurrentFrame();
  const p = ramp(frame, at, at + 9);
  const q = exitAt === undefined ? 0 : ramp(frame, exitAt, exitAt + 8);
  const blur = (1 - p) * 12 + q * 10;
  const glow = grad ? ' drop-shadow(0 6px 22px rgba(255,90,54,0.35))' : '';
  return (
    <span
      style={{
        display: 'inline-block',
        fontFamily: font,
        fontWeight: weight,
        fontSize: size,
        lineHeight: 1.02,
        letterSpacing: spacing,
        opacity: p * (1 - q),
        transform: `translate(${(1 - p) * dx}px, ${(1 - p) * 24 - q * 30}px)`,
        filter: `blur(${blur}px)${glow}`,
        willChange: 'transform, filter, opacity',
        ...(grad
          ? {backgroundImage: GRAD, WebkitBackgroundClip: 'text', backgroundClip: 'text', color: 'transparent'}
          : {color}),
        ...style,
      }}
    >
      {children}
    </span>
  );
};

export const Row: React.FC<{
  children: React.ReactNode;
  gap?: number;
  align?: 'center' | 'flex-start';
  style?: React.CSSProperties;
}> = ({children, gap = 28, align = 'center', style}) => (
  <div style={{display: 'flex', gap, justifyContent: align, alignItems: 'baseline', ...style}}>{children}</div>
);
