import React from 'react';
import {C} from '../lib/constants';

export const Cursor: React.FC<{x: number; y: number; scale?: number}> = ({x, y, scale = 1}) => (
  <svg
    width={110}
    height={110}
    viewBox="0 0 24 24"
    style={{position: 'absolute', left: x, top: y, transform: `scale(${scale})`, transformOrigin: '4px 2px', filter: 'drop-shadow(0 10px 14px rgba(42,7,3,0.35))', zIndex: 50}}
  >
    <path d="M4 2 L4 20 L9 15.5 L12.5 23 L15.5 21.5 L12 14 L19 14 Z" fill="#fff" stroke={C.ink} strokeWidth={1.4} strokeLinejoin="round" />
  </svg>
);
