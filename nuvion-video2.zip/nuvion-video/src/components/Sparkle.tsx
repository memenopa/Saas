import React from 'react';
import {C} from '../lib/constants';

export const SPARKLE_PATH =
  'M50 0 C54 30 70 46 100 50 C70 54 54 70 50 100 C46 70 30 54 0 50 C30 46 46 30 50 0 Z';

export const Sparkle: React.FC<{
  size: number;
  rotate?: number;
  scale?: number;
  fill?: string;
  grad?: boolean;
  style?: React.CSSProperties;
}> = ({size, rotate = 0, scale = 1, fill = C.ember, grad = false, style}) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 100 100"
    style={{overflow: 'visible', transform: `rotate(${rotate}deg) scale(${scale})`, ...style}}
  >
    {grad && (
      <defs>
        <linearGradient id="spk" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor={C.ember} />
          <stop offset="1" stopColor={C.peach} />
        </linearGradient>
      </defs>
    )}
    <path d={SPARKLE_PATH} fill={grad ? 'url(#spk)' : fill} />
  </svg>
);
