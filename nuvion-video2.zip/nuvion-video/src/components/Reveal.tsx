import React from 'react';
import {AbsoluteFill, Easing, interpolate, useCurrentFrame} from 'remotion';
import {clampOpts} from '../lib/motion';

export type RevealType = 'circle' | 'wipeL' | 'wipeUp' | 'fade' | 'none';

/** Scene entrance. The new scene is layered on top of the previous one, which is still animating beneath. */
export const Reveal: React.FC<{
  type: RevealType;
  frames?: number;
  origin?: [number, number];
  children: React.ReactNode;
}> = ({type, frames = 10, origin = [960, 540], children}) => {
  const frame = useCurrentFrame();
  const p = interpolate(frame, [0, frames], [0, 1], {
    ...clampOpts,
    easing: Easing.bezier(0.7, 0, 0.2, 1),
  });
  const style: React.CSSProperties = {};
  if (p < 1) {
    if (type === 'circle') style.clipPath = `circle(${p * 175}% at ${origin[0]}px ${origin[1]}px)`;
    if (type === 'wipeL') style.clipPath = `inset(0 0 0 ${(1 - p) * 100}%)`;
    if (type === 'wipeUp') style.clipPath = `inset(${(1 - p) * 100}% 0 0 0)`;
    if (type === 'fade') style.opacity = p;
  }
  return <AbsoluteFill style={style}>{children}</AbsoluteFill>;
};
