import React from 'react';
import {AbsoluteFill, useCurrentFrame, useVideoConfig} from 'remotion';

/** Continuous slow push + drift so no shot is ever static. */
export const Camera: React.FC<{
  children: React.ReactNode;
  amp?: number;
  zoom?: number;
  seed?: number;
}> = ({children, amp = 1, zoom = 0.06, seed = 0}) => {
  const frame = useCurrentFrame();
  const {durationInFrames} = useVideoConfig();
  const p = frame / Math.max(1, durationInFrames);
  const s = 1 + zoom * p;
  const x = Math.sin(frame / 38 + seed) * 14 * amp;
  const y = Math.cos(frame / 46 + seed) * 10 * amp;
  const r = Math.sin(frame / 90 + seed) * 0.35 * amp;
  return (
    <AbsoluteFill style={{transform: `translate(${x}px, ${y}px) scale(${s}) rotate(${r}deg)`}}>
      {children}
    </AbsoluteFill>
  );
};
