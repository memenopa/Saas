import React from 'react';
import {useCurrentFrame} from 'remotion';
import {C, FONT_BODY, FONT_HEAD, GRAD} from '../lib/constants';
import {glass} from './Pill';
import {ramp} from '../lib/motion';

const BAL = [
  {g: '$', code: 'USD', amt: '48,210.00'},
  {g: '€', code: 'EUR', amt: '31,905.40'},
  {g: '£', code: 'GBP', amt: '12,480.75'},
];

const bar = (w: string, o = 0.6): React.CSSProperties => ({height: 14, width: w, borderRadius: 999, background: C.peach, opacity: o});

/** Abstract vector dashboard (no screenshots): sidebar, balance cards, live chart, skeleton rows. */
export const Dashboard: React.FC<{width?: number; height?: number}> = ({width = 1050, height = 620}) => {
  const frame = useCurrentFrame();
  const draw = ramp(frame, 8, 60);
  const pts = new Array(14).fill(0).map((_, i) => {
    const x = (i / 13) * 560;
    const y = 170 - (i * 7.5 + Math.sin(i * 1.3 + frame / 12) * 14);
    return [x, y] as const;
  });
  const d = pts.map(([x, y], i) => `${i ? 'L' : 'M'}${x.toFixed(1)} ${y.toFixed(1)}`).join(' ');
  return (
    <div style={{...glass('light'), width, height, borderRadius: 40, display: 'flex', overflow: 'hidden', boxSizing: 'border-box'}}>
      <div style={{width: 96, background: 'rgba(42,7,3,0.04)', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 22, paddingTop: 30}}>
        <div style={{width: 48, height: 48, borderRadius: 16, background: GRAD}} />
        {[0, 1, 2, 3, 4].map((i) => (
          <div key={i} style={{width: 36, height: 36, borderRadius: 12, background: C.peach, opacity: i === (Math.floor(frame / 24) % 5) ? 1 : 0.4}} />
        ))}
      </div>
      <div style={{flex: 1, padding: 30}}>
        <div style={{display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24}}>
          <div>
            <div style={{fontFamily: FONT_HEAD, fontWeight: 800, fontSize: 38, color: C.ink, letterSpacing: '-0.03em'}}>Global accounts</div>
            <div style={{...bar('180px', 0.5), marginTop: 10}} />
          </div>
          <div style={{width: 220, height: 50, borderRadius: 999, background: 'rgba(255,255,255,0.8)', border: `1px solid ${C.blushDeep}`}} />
        </div>
        <div style={{display: 'flex', gap: 20, marginBottom: 24}}>
          {BAL.map((b, i) => (
            <div key={b.code} style={{flex: 1, borderRadius: 26, background: '#fff', padding: 20, boxShadow: '0 10px 30px rgba(255,90,54,0.12)', transform: `translateY(${Math.sin(frame / 15 + i) * 4}px)`}}>
              <div style={{display: 'flex', alignItems: 'center', gap: 12}}>
                <div style={{width: 44, height: 44, borderRadius: 14, background: GRAD, color: '#fff', fontFamily: FONT_BODY, fontWeight: 700, fontSize: 26, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>{b.g}</div>
                <div style={{fontFamily: FONT_BODY, fontWeight: 600, fontSize: 24, color: C.inkSoft}}>{b.code}</div>
              </div>
              <div style={{fontFamily: FONT_HEAD, fontWeight: 800, fontSize: 40, color: C.ink, marginTop: 16, letterSpacing: '-0.03em'}}>{b.amt}</div>
            </div>
          ))}
        </div>
        <div style={{display: 'flex', gap: 20}}>
          <div style={{flex: 1.5, borderRadius: 26, background: '#fff', padding: 20, boxShadow: '0 10px 30px rgba(255,90,54,0.12)'}}>
            <svg width={560} height={190} viewBox="0 0 560 190" style={{overflow: 'visible'}}>
              <path d={d} fill="none" stroke={C.ember} strokeWidth={6} strokeLinecap="round" strokeLinejoin="round" pathLength={1} strokeDasharray={1} strokeDashoffset={1 - draw} />
            </svg>
          </div>
          <div style={{flex: 1, borderRadius: 26, background: '#fff', padding: 20, display: 'flex', flexDirection: 'column', gap: 18, boxShadow: '0 10px 30px rgba(255,90,54,0.12)'}}>
            {[0, 1, 2].map((i) => (
              <div key={i} style={{display: 'flex', alignItems: 'center', gap: 12}}>
                <div style={{width: 36, height: 36, borderRadius: 12, background: C.peach, opacity: 0.7}} />
                <div style={{flex: 1}}>
                  <div style={bar('80%')} />
                  <div style={{...bar('50%', 0.35), marginTop: 8}} />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
