import React from 'react';
import {useCurrentFrame} from 'remotion';
import {C, FONT_BODY, FONT_HEAD} from '../lib/constants';
import {ramp} from '../lib/motion';

export type CloudItem = {text: string; z: number; a0: number; rx: number; ry: number; speed: number};

/** Z-axis depth-of-field word cloud. Items with z<1 render behind (`layer="back"`), z>=1 in front. */
export const ZCloud: React.FC<{
  items: CloudItem[];
  layer: 'back' | 'front';
  cx?: number;
  cy?: number;
  start?: number;
  dark?: boolean;
}> = ({items, layer, cx = 960, cy = 540, start = 0, dark = true}) => {
  const frame = useCurrentFrame();
  return (
    <>
      {items
        .filter((it) => (layer === 'back' ? it.z < 1 : it.z >= 1))
        .map((it, i) => {
          const a = it.a0 + frame * it.speed;
          const x = cx + Math.cos(a) * it.rx;
          const y = cy + Math.sin(a) * it.ry;
          const blur = Math.abs(it.z - 1) * 8;
          const appear = ramp(frame, start + i * 3, start + i * 3 + 10);
          return (
            <div
              key={it.text + i}
              style={{
                position: 'absolute',
                left: x,
                top: y,
                transform: `translate(-50%, -50%) scale(${it.z})`,
                filter: `blur(${blur}px)`,
                opacity: appear * (it.z < 1 ? 0.55 : 0.9),
                fontFamily: it.text.length <= 4 ? FONT_BODY : FONT_HEAD,
                fontWeight: 700,
                fontSize: 54,
                letterSpacing: '-0.03em',
                color: dark ? C.peach : C.ember,
                whiteSpace: 'nowrap',
              }}
            >
              {it.text}
            </div>
          );
        })}
    </>
  );
};
