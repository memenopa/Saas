import React from 'react';
import {AbsoluteFill, Audio, Sequence, staticFile} from 'remotion';
import {Reveal, RevealType} from './components/Reveal';
import {DURATION, OVERLAP, SCENES, SceneKey, sec} from './lib/constants';
import {Scene1Hook} from './scenes/Scene1Hook';
import {Scene2Meet} from './scenes/Scene2Meet';
import {Scene3Eco} from './scenes/Scene3Eco';
import {Scene4Fx} from './scenes/Scene4Fx';
import {Scene5Pay} from './scenes/Scene5Pay';
import {Scene6Borders} from './scenes/Scene6Borders';
import {Scene7Build} from './scenes/Scene7Build';
import {Scene8AI} from './scenes/Scene8AI';
import {Scene9Limits} from './scenes/Scene9Limits';
import {Scene10Logo} from './scenes/Scene10Logo';
import {Scene11Tag} from './scenes/Scene11Tag';

type Item = {key: SceneKey; C: React.FC; reveal: RevealType; origin?: [number, number]};

// Order matters: each scene is layered on top of the previous one, which keeps animating underneath.
const TIMELINE: Item[] = [
  {key: 'hook', C: Scene1Hook, reveal: 'none'},
  {key: 'meet', C: Scene2Meet, reveal: 'fade'},
  {key: 'eco', C: Scene3Eco, reveal: 'circle', origin: [960, 640]},
  {key: 'fx', C: Scene4Fx, reveal: 'wipeL'},
  {key: 'pay', C: Scene5Pay, reveal: 'wipeUp'},
  {key: 'borders', C: Scene6Borders, reveal: 'circle', origin: [200, 900]},
  {key: 'build', C: Scene7Build, reveal: 'wipeL'},
  {key: 'ai', C: Scene8AI, reveal: 'circle', origin: [960, 540]},
  {key: 'limits', C: Scene9Limits, reveal: 'wipeUp'},
  {key: 'logo', C: Scene10Logo, reveal: 'circle', origin: [960, 540]},
  {key: 'tag', C: Scene11Tag, reveal: 'circle', origin: [960, 540]},
];

export const Video: React.FC = () => (
  <AbsoluteFill style={{background: '#150403'}}>
    <Audio src={staticFile('voiceover.mp3')} />
    {TIMELINE.map(({key, C: Scene, reveal, origin}, i) => {
      const from = sec(SCENES[key].from);
      const isLast = i === TIMELINE.length - 1;
      const dur = isLast ? DURATION - from : sec(SCENES[key].to) - from + OVERLAP;
      return (
        <Sequence key={key} from={from} durationInFrames={dur} name={key}>
          <Reveal type={reveal} origin={origin} frames={reveal === 'fade' ? 5 : 10}>
            <Scene />
          </Reveal>
        </Sequence>
      );
    })}
  </AbsoluteFill>
);
