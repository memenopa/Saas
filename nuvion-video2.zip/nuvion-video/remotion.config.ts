import {Config} from '@remotion/cli/config';

// Rendering is capped at 2 parallel browser tabs (Codespaces-friendly).
Config.setConcurrency(2);
Config.setVideoImageFormat('jpeg');
Config.setOverwriteOutput(true);
