Drop the Nuvion Sans headline font here as NuvionSans.woff2 (or .otf / .ttf).
It is picked up automatically (see src/lib/fonts.ts). Until then, headlines use Outfit ExtraBold
as a close geometric stand-in. Body text uses Inter.
