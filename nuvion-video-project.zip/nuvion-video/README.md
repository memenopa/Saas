# Nuvion brand film — Remotion project

A motion-led, voiceover-driven Nuvion brand film for YouTube, built with React + TypeScript + Remotion.

## Specs

- 1920 × 1080 (16:9)
- 60 fps
- 26.45 seconds / 1,587 frames
- Supplied ElevenLabs voiceover included at `public/audio/nuvion-voiceover.mp3`
- All animation is deterministic and frame-driven with Remotion hooks.
- No CSS keyframes, timers, random runtime values, or static-shot scene design.

## Run in GitHub Codespaces

```bash
npm install
npm run start
```

Open the forwarded Remotion Studio port shown by Codespaces (typically 3000).

## Render the video

```bash
npm run render
```

The rendered MP4 is written to `out/nuvion-brand-film.mp4`.

To render a still preview:

```bash
npm run still
```

## Build verification

The source files and project configuration are packaged. A full Remotion render was not run in the build environment because npm dependency installation could not complete there (network access was unavailable). Run `npm install` in GitHub Codespaces, then use `npm run start` or `npm run render`.

## Brand assets / final polish

1. The requested Nuvion Sans headline family is configured in `src/global.css`. Add a licensed webfont at `public/fonts/NuvionSans.woff2`.
2. The current vector wordmark is a clean motion-ready placeholder because the public website did not expose a downloadable brand SVG in the supplied research. Replace the `Wordmark` component in `src/scenes/shared.tsx` with official artwork if supplied.
3. The body font uses a neo-grotesque stack (Inter / Helvetica Neue / Arial).
4. Brand color values are centralized in `src/theme.ts`. The vivid plum / violet / lavender / coral direction is an interpretation, not a claim that these are exact official website CSS tokens.

## Project map

- `src/Root.tsx` — composition registration, 16:9 / 60 fps / 1,587 frames.
- `src/NuvionBrandFilm.tsx` — scene sequence and voiceover track.
- `src/scenes/` — modular animated scenes and shared motion primitives.
- `src/theme.ts` — color and font tokens.
- `public/audio/` — supplied voiceover.
- `docs/STORYBOARD.md` — scene timing, narration, and visual choreography.

## Content accuracy

The official Nuvion site presents Nuvion as AI-powered global banking and cross-border payments infrastructure. The film references multi-currency accounts, payments, payouts, global card issuing, stablecoin rails, market access, and Nuvion IQ. UI figures and sample transaction data are illustrative motion-graphics elements only.

## Official references

- https://nuvion.co/
- https://nuvion.co/products
- https://nuvion.co/about
- https://nuvion.co/products/payout
