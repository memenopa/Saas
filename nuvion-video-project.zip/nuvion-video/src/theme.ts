export const C = {
  ink: '#080214',
  ink2: '#120B25',
  plum: '#25113B',
  violet: '#8D3CFD',
  lavender: '#C4A3D3',
  lilac: '#A173CD',
  pale: '#F8EBFA',
  white: '#FFFFFF',
  muted: '#B9ADC8',
  coral: '#CB4930',
  slate: '#9397BC',
  mint: '#9CF3D3',
};

export const FONT_HEAD = 'Nuvion Sans, Inter, "Arial", sans-serif';
export const FONT_BODY = 'Inter, "Helvetica Neue", Arial, sans-serif';
