import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame, useVideoConfig, spring} from 'remotion';
import {Ambient, clamp, Wordmark} from './shared';
import {C} from '../theme';

export const SceneMeet: React.FC = () => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const p = spring({frame: f - 4, fps, config: {damping: 13, stiffness: 105, mass: .8}});
  const spin = interpolate(f, [0, 85], [-80, 0], clamp);
  const glow = interpolate(f, [0, 30, 85], [0, 1, .55], clamp);
  return <AbsoluteFill style={{overflow: 'hidden', justifyContent: 'center', alignItems: 'center'}}>
    <Ambient accent={C.lavender}/>
    <div style={{position: 'absolute', width: 560, height: 560, border: '1px solid rgba(196,163,211,.35)', borderRadius: '50%', transform: `rotate(${spin}deg) scale(${.6 + p*.4})`, boxShadow: `0 0 ${80*glow}px ${C.violet}55`}}>
      {[0,1,2].map(i=><div key={i} style={{position:'absolute',inset:40+i*65,border:'1px solid rgba(196,163,211,.22)',borderRadius:'50%',transform:`rotateX(${60+i*10}deg) rotateY(${i*28}deg)`}}/>)}
    </div>
    <div style={{position:'absolute',top:260,fontSize:24,fontWeight:700,letterSpacing:'.34em',color:C.lavender,opacity:interpolate(f,[0,12,75],[0,1,1],clamp)}}>MEET</div>
    <div style={{transform:`scale(${p}) rotateX(${(1-p)*22}deg)`,filter:`drop-shadow(0 24px 60px ${C.violet}66)`}}><Wordmark size={150}/></div>
    <div style={{position:'absolute',width:14,height:14,borderRadius:'50%',background:C.pale,boxShadow:`0 0 30px ${C.pale}`,left:`${50+Math.cos(f*.11)*20}%`,top:`${50+Math.sin(f*.11)*20}%`}}/>
  </AbsoluteFill>;
};
