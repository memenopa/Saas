import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame, useVideoConfig, spring} from 'remotion';
import {Ambient, clamp, Wordmark} from './shared';
import {C, FONT_HEAD} from '../theme';

export const SceneOutro: React.FC = () => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const p = spring({frame:f-4,fps,config:{damping:15,stiffness:100,mass:.8}});
  const star = interpolate(f,[60,85,110],[1,18,95],clamp);
  const tagline = interpolate(f,[84,105,156],[0,1,1],clamp);
  const logo = interpolate(f,[26,42,156],[0,1,1],clamp);
  const bg = interpolate(f,[0,60,156],[1,1,.7],clamp);
  return <AbsoluteFill style={{overflow:'hidden',justifyContent:'center',alignItems:'center'}}>
    <Ambient accent={C.violet}/>
    <div style={{position:'absolute',width:800,height:800,border:'1px solid rgba(196,163,211,.25)',borderRadius:'50%',transform:`scale(${.65+p*.35}) rotate(${f*.2}deg)`,boxShadow:'0 0 100px rgba(141,60,253,.16)'}} />
    <div style={{position:'absolute',top:260,textAlign:'center',opacity:tagline,transform:`translateY(${(1-tagline)*28}px)`,fontFamily:FONT_HEAD,fontWeight:700,fontSize:105,letterSpacing:'-.065em',lineHeight:1.0}}>GO <span style={{color:C.lavender}}>BORDERLESS.</span></div>
    <div style={{position:'absolute',top:520,transform:`scale(${logo}) translateY(${(1-logo)*40}px)`,opacity:logo}}><Wordmark size={132}/></div>
    <div style={{position:'absolute',left:'50%',top:'50%',fontSize:40,color:C.pale,transform:`translate(-50%,-50%) scale(${star}) rotate(${f*7}deg)`,opacity:interpolate(f,[60,85,116],[0,.9,0],clamp),textShadow:`0 0 45px ${C.lavender}`}}>✦</div>
    <div style={{position:'absolute',bottom:82,fontSize:18,letterSpacing:'.3em',color:'#B7A9C9',opacity:bg}}>NUVION.CO</div>
  </AbsoluteFill>;
};
