import React from 'react';
import {AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {C, FONT_BODY, FONT_HEAD} from '../theme';

export const clamp = {extrapolateLeft: 'clamp' as const, extrapolateRight: 'clamp' as const};

export const Wordmark: React.FC<{size?: number; dark?: boolean}> = ({size = 68, dark = false}) => (
  <div style={{display: 'flex', alignItems: 'center', gap: size * 0.14, fontFamily: FONT_HEAD, fontSize: size, fontWeight: 700, letterSpacing: '-0.065em', color: dark ? C.ink : C.white, lineHeight: 0.9}}>
    <svg width={size * 0.72} height={size * 0.72} viewBox="0 0 64 64" fill="none" aria-label="Nuvion symbol">
      <path d="M10 47V17L32 42V17M54 17V47L32 22" stroke={dark ? C.violet : C.pale} strokeWidth="7" strokeLinecap="round" strokeLinejoin="round" />
      <circle cx="32" cy="32" r="29" stroke={dark ? C.violet : C.lilac} strokeOpacity=".55" strokeWidth="1.5" />
    </svg>
    <span>nuvion</span>
  </div>
);

export const Ambient: React.FC<{light?: boolean; accent?: string}> = ({light = false, accent = C.violet}) => {
  const f = useCurrentFrame();
  const {width, height} = useVideoConfig();
  const drift = Math.sin(f / 42) * 55;
  const drift2 = Math.cos(f / 57) * 45;
  return <AbsoluteFill style={{overflow: 'hidden', background: light ? `linear-gradient(135deg, ${C.pale}, #FFFFFF 52%, #EEE4FA)` : `linear-gradient(135deg, ${C.ink}, ${C.ink2} 55%, #1D1030)`}}>
    <div style={{position: 'absolute', width: 900, height: 900, borderRadius: '50%', left: width * 0.54 + drift, top: -360 + drift2, background: `radial-gradient(circle, ${accent}55 0%, ${accent}20 35%, transparent 70%)`, filter: 'blur(24px)'}} />
    <div style={{position: 'absolute', width: 700, height: 700, borderRadius: '50%', left: -250 - drift2, bottom: -420 + drift, background: `radial-gradient(circle, ${light ? C.lavender : C.violet}35 0%, transparent 70%)`, filter: 'blur(30px)'}} />
    <div style={{position: 'absolute', inset: 0, opacity: light ? 0.08 : 0.12, backgroundImage: `linear-gradient(${light ? '#563E68' : '#DCC9F5'} 1px, transparent 1px), linear-gradient(90deg, ${light ? '#563E68' : '#DCC9F5'} 1px, transparent 1px)`, backgroundSize: '84px 84px', transform: `translate(${(f * -0.35) % 84}px, ${(f * -0.22) % 84}px)`}} />
  </AbsoluteFill>;
};

export const Eyebrow: React.FC<{children: React.ReactNode; light?: boolean}> = ({children, light = false}) => (
  <div style={{fontFamily: FONT_BODY, fontSize: 20, fontWeight: 700, letterSpacing: '.22em', textTransform: 'uppercase', color: light ? '#725C82' : C.lavender}}>{children}</div>
);

export const Reveal: React.FC<{children: React.ReactNode; from?: number; duration?: number; y?: number; style?: React.CSSProperties}> = ({children, from = 0, duration = 24, y = 44, style}) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const p = spring({frame: f - from, fps, config: {damping: 18, stiffness: 120, mass: 0.75}});
  const opacity = interpolate(f, [from, from + duration], [0, 1], clamp);
  return <div style={{opacity, transform: `translate3d(0, ${(1 - p) * y}px, 0) scale(${0.96 + p * 0.04})`, ...style}}>{children}</div>;
};

export const GlassCard: React.FC<{children: React.ReactNode; width?: number; height?: number; style?: React.CSSProperties}> = ({children, width = 360, height = 210, style}) => (
  <div style={{width, height, borderRadius: 28, padding: 26, boxSizing: 'border-box', background: 'linear-gradient(145deg, rgba(255,255,255,.16), rgba(255,255,255,.045))', border: '1px solid rgba(255,255,255,.22)', boxShadow: '0 24px 70px rgba(0,0,0,.28), inset 0 1px 0 rgba(255,255,255,.16)', backdropFilter: 'blur(18px)', ...style}}>{children}</div>
);

export const OrbitingDot: React.FC<{radius: number; speed?: number; phase?: number; size?: number; color?: string}> = ({radius, speed = 1, phase = 0, size = 14, color = C.lavender}) => {
  const f = useCurrentFrame();
  const a = f * 0.018 * speed + phase;
  return <div style={{position: 'absolute', left: `calc(50% + ${Math.cos(a) * radius}px)`, top: `calc(50% + ${Math.sin(a) * radius * 0.56}px)`, width: size, height: size, borderRadius: '50%', background: color, boxShadow: `0 0 24px ${color}`, transform: 'translate(-50%, -50%)'}} />;
};

export const CurrencyChip: React.FC<{label: string; x: number; y: number; delay?: number; color?: string}> = ({label, x, y, delay = 0, color = C.pale}) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const p = spring({frame: f - delay, fps, config: {damping: 14, stiffness: 115}});
  const bob = Math.sin((f + delay) / 13) * 8;
  return <div style={{position: 'absolute', left: x, top: y + bob, opacity: interpolate(f, [delay, delay + 18], [0, 1], clamp), transform: `translate(-50%, -50%) scale(${p}) rotate(${Math.sin((f + delay) / 25) * 5}deg)`, padding: '13px 22px', borderRadius: 999, background: 'rgba(255,255,255,.12)', border: '1px solid rgba(255,255,255,.26)', color, fontSize: 24, fontWeight: 700, boxShadow: '0 12px 34px rgba(0,0,0,.18)', backdropFilter: 'blur(12px)'}}>{label}</div>;
};

export const MotionLine: React.FC<{x1: number; y1: number; x2: number; y2: number; delay?: number; color?: string}> = ({x1, y1, x2, y2, delay = 0, color = C.lilac}) => {
  const f = useCurrentFrame();
  const dash = interpolate(f - delay, [0, 45], [500, 0], clamp);
  return <svg style={{position: 'absolute', inset: 0, width: '100%', height: '100%', overflow: 'visible'}} viewBox="0 0 1920 1080"><path d={`M ${x1} ${y1} Q ${(x1 + x2) / 2 + 20} ${(y1 + y2) / 2 - 70} ${x2} ${y2}`} fill="none" stroke={color} strokeWidth="2" strokeOpacity=".55" strokeDasharray="500" strokeDashoffset={dash} /></svg>;
};
