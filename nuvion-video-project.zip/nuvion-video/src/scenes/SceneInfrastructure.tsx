import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame} from 'remotion';
import {Ambient, clamp, Eyebrow, GlassCard, OrbitingDot, Wordmark} from './shared';
import {C, FONT_HEAD, FONT_BODY} from '../theme';

export const SceneInfrastructure: React.FC = () => {
  const f = useCurrentFrame();
  const zoom = interpolate(f,[0,242],[.84,1.12],clamp);
  const turn = f*.18;
  const reveal = interpolate(f,[0,24,240],[0,1,1],clamp);
  const secondLine = interpolate(f,[128,150,240],[0,1,1],clamp);
  return <AbsoluteFill style={{overflow:'hidden'}}>
    <Ambient accent={C.lilac}/>
    <div style={{position:'absolute',left:'50%',top:'53%',width:620,height:620,transform:`translate(-50%,-50%) scale(${zoom}) rotate(${turn}deg)`,border:'1px solid rgba(196,163,211,.35)',borderRadius:'50%',boxShadow:'0 0 110px rgba(141,60,253,.18)'}}>
      {[0,1,2,3].map(i=><div key={i} style={{position:'absolute',inset:55+i*48,border:'1px solid rgba(196,163,211,.25)',borderRadius:'50%',transform:`rotateX(${45+i*13}deg) rotateY(${i*27}deg)`}}/>)}
      <OrbitingDot radius={285} speed={1.2} phase={0} color={C.pale} size={18}/><OrbitingDot radius={285} speed={-.8} phase={2.3} color={C.coral} size={15}/><OrbitingDot radius={285} speed={.65} phase={4.3} color={C.lavender} size={13}/>
    </div>
    <div style={{position:'absolute',left:0,right:0,top:165,textAlign:'center',opacity:reveal,transform:`translateY(${(1-reveal)*35}px)`}}>
      <Eyebrow>Intelligence at the core</Eyebrow>
      <div style={{fontFamily:FONT_HEAD,fontSize:88,fontWeight:700,letterSpacing:'-.065em',lineHeight:1.03,marginTop:26}}>POWERED BY <span style={{color:C.lavender}}>INTELLIGENT</span><br/>TECHNOLOGY.</div>
      <div style={{fontFamily:FONT_BODY,fontSize:26,color:'#D3C8E0',marginTop:28}}>One intelligence layer. A world of financial possibility.</div>
      <div style={{fontFamily:FONT_HEAD,fontSize:43,fontWeight:700,letterSpacing:'-.04em',marginTop:32,opacity:secondLine,transform:`translateY(${(1-secondLine)*20}px)`}}>BUILT FOR A WORLD WITHOUT LIMITS.</div>
    </div>
    <div style={{position:'absolute',left:'50%',top:'66%',transform:'translate(-50%,-50%)',opacity:reveal}}>
      <GlassCard width={430} height={118} style={{display:'flex',alignItems:'center',gap:20,borderRadius:24}}><div style={{width:52,height:52,borderRadius:18,background:'linear-gradient(135deg,#8D3CFD,#CB4930)',display:'grid',placeItems:'center',fontSize:26}}>✦</div><div><div style={{fontSize:21,fontWeight:800}}>NUVION IQ</div><div style={{fontSize:16,color:C.muted,marginTop:6}}>Your smartest financial teammate</div></div><div style={{marginLeft:'auto',fontSize:24,color:C.mint}}>●</div></GlassCard>
    </div>
  </AbsoluteFill>;
};
