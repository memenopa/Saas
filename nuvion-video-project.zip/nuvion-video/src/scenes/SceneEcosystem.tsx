import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame} from 'remotion';
import {Ambient, clamp, Eyebrow, GlassCard, MotionLine, Reveal} from './shared';
import {C, FONT_HEAD, FONT_BODY} from '../theme';

const MiniBar: React.FC<{w: number; color?: string}> = ({w,color=C.lavender}) => <div style={{width:w,height:9,borderRadius:99,background:color,opacity:.85}}/>;

export const SceneEcosystem: React.FC = () => {
  const f = useCurrentFrame();
  const pulse = 1 + Math.sin(f/12)*.035;
  const orbit = f*.55;
  const cards = [
    {title:'GLOBAL ACCOUNTS',sub:'Hold & manage currencies',icon:'◎',x:190,y:280,delay:20},
    {title:'PAYMENTS',sub:'Accept from anywhere',icon:'↗',x:1340,y:260,delay:36},
    {title:'PAYOUTS',sub:'Move money across borders',icon:'⇢',x:220,y:690,delay:52},
    {title:'CARDS',sub:'Spend with global control',icon:'▰',x:1330,y:680,delay:68},
  ];
  return <AbsoluteFill style={{overflow:'hidden'}}>
    <Ambient accent={C.violet}/>
    <div style={{position:'absolute',left:0,right:0,top:105,textAlign:'center'}}><Eyebrow>One connected financial ecosystem</Eyebrow><div style={{fontFamily:FONT_HEAD,fontSize:80,fontWeight:700,letterSpacing:'-.06em',marginTop:18}}>EVERYTHING <span style={{color:C.lavender}}>IN SYNC.</span></div></div>
    <div style={{position:'absolute',left:'50%',top:'53%',width:520,height:520,transform:`translate(-50%,-50%) rotate(${orbit}deg) scale(${pulse})`,borderRadius:'50%',border:'1px solid rgba(196,163,211,.34)',boxShadow:'0 0 100px rgba(141,60,253,.18)'}}>
      <div style={{position:'absolute',inset:54,borderRadius:'50%',border:'1px dashed rgba(196,163,211,.34)'}}/><div style={{position:'absolute',inset:110,borderRadius:'50%',border:'1px solid rgba(196,163,211,.2)'}}/>
    </div>
    <div style={{position:'absolute',left:'50%',top:'53%',transform:'translate(-50%,-50%)',zIndex:5}}>
      <div style={{width:270,height:270,borderRadius:62,display:'flex',alignItems:'center',justifyContent:'center',background:'linear-gradient(145deg,rgba(255,255,255,.2),rgba(141,60,253,.2))',border:'1px solid rgba(255,255,255,.3)',boxShadow:'0 30px 100px rgba(141,60,253,.35)',backdropFilter:'blur(20px)',transform:`scale(${pulse})`}}><div style={{fontSize:94,fontWeight:700,color:C.pale}}>N</div></div>
    </div>
    {cards.map((c,i)=><React.Fragment key={c.title}><MotionLine x1={960} y1={570} x2={c.x+190} y2={c.y+100} delay={c.delay}/><div style={{position:'absolute',left:c.x,top:c.y,transform:`translateY(${Math.sin((f+c.delay)/13)*8}px)`,zIndex:6}}><Reveal from={c.delay}><GlassCard width={390} height={180}><div style={{display:'flex',alignItems:'center',gap:16}}><div style={{width:54,height:54,borderRadius:18,display:'grid',placeItems:'center',background:'rgba(196,163,211,.2)',color:C.pale,fontSize:32}}>{c.icon}</div><div style={{fontSize:19,letterSpacing:'.12em',fontWeight:800}}>{c.title}</div></div><div style={{marginTop:20,fontSize:20,color:'#D4C9DE'}}>{c.sub}</div><div style={{display:'flex',gap:9,marginTop:18}}><MiniBar w={95}/><MiniBar w={58} color={C.lilac}/><MiniBar w={38} color={C.coral}/></div></GlassCard></Reveal></div></React.Fragment>)}
    <div style={{position:'absolute',bottom:48,left:0,right:0,textAlign:'center',fontFamily:FONT_BODY,fontSize:20,letterSpacing:'.18em',color:C.muted}}>ACCOUNTS  ·  PAYMENTS  ·  PAYOUTS  ·  CARDS</div>
  </AbsoluteFill>;
};
