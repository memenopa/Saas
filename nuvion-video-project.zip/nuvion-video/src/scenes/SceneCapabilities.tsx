import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame} from 'remotion';
import {Ambient, clamp, CurrencyChip, Eyebrow, GlassCard, Reveal, Wordmark} from './shared';
import {C, FONT_HEAD, FONT_BODY} from '../theme';

const Capability: React.FC<{title:string;sub:string;kind:string;index:number}> = ({title,sub,kind,index}) => {
  const f = useCurrentFrame();
  const phases = [28,126,246,327];
  const ends = [118,235,320,585];
  const phase = phases[index];
  const duration = ends[index] - phase;
  const local = f-phase;
  const opacity = interpolate(local,[0,16,duration-18,duration],[0,1,1,0],clamp);
  const x = interpolate(local,[0,18,duration-18,duration],[130,0,0,-80],clamp);
  const scale = interpolate(local,[0,22,duration-18,duration],[.88,1,1,1.08],clamp);
  const rotate = Math.sin((local+index*30)/24)*2;
  return <div style={{position:'absolute',inset:0,opacity,transform:`translateX(${x}px) scale(${scale})`,pointerEvents:'none'}}>
    <div style={{position:'absolute',left:180,top:285,width:700}}>
      <Eyebrow>Global capability 0{index+1}</Eyebrow>
      <div style={{fontFamily:FONT_HEAD,fontSize:88,fontWeight:700,letterSpacing:'-.065em',lineHeight:.98,whiteSpace:'pre-line',marginTop:28}}>{title}</div>
      <div style={{fontFamily:FONT_BODY,fontSize:29,color:'#D3C8E0',marginTop:30,maxWidth:650,lineHeight:1.35}}>{sub}</div>
    </div>
    <div style={{position:'absolute',right:180,top:230,width:660,height:570,transform:`perspective(1200px) rotateX(${10+rotate}deg) rotateY(-12deg) rotateZ(${rotate}deg)`}}>
      <GlassCard width={620} height={470} style={{padding:34,borderRadius:38,background:'linear-gradient(145deg,rgba(255,255,255,.19),rgba(255,255,255,.055))'}}>
        {kind==='fx' && <>
          <div style={{display:'flex',justifyContent:'space-between',fontSize:18,color:C.muted,letterSpacing:'.14em'}}>CURRENCY EXCHANGE <span>LIVE</span></div>
          <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginTop:62}}><div><div style={{fontSize:18,color:C.muted}}>YOU SEND</div><div style={{fontSize:68,fontWeight:800,letterSpacing:'-.06em'}}>€12,500</div><div style={{fontSize:22,color:C.lavender}}>EUR · Euro</div></div><div style={{fontSize:56,color:C.lavender}}>⇄</div><div><div style={{fontSize:18,color:C.muted}}>YOU RECEIVE</div><div style={{fontSize:68,fontWeight:800,letterSpacing:'-.06em'}}>$13,625</div><div style={{fontSize:22,color:C.lavender}}>USD · US Dollar</div></div></div>
          <div style={{marginTop:48,padding:20,borderRadius:20,background:'rgba(141,60,253,.17)',fontSize:20,color:C.pale}}>Transparent FX · One connected account</div>
        </>}
        {kind==='pay' && <>
          <div style={{fontSize:18,color:C.muted,letterSpacing:'.14em'}}>PAYMENT RECEIVED</div><div style={{fontSize:86,fontWeight:800,marginTop:26,letterSpacing:'-.06em'}}>+$8,420<span style={{fontSize:32,color:C.mint}}> .00</span></div><div style={{fontSize:22,color:C.mint,marginTop:4}}>✓  Payment settled</div>
          <div style={{display:'flex',gap:16,marginTop:58}}>{['VISA','MC','LOCAL','WALLET'].map((v,i)=><div key={v} style={{flex:1,height:74,borderRadius:16,display:'grid',placeItems:'center',background:'rgba(255,255,255,.1)',border:'1px solid rgba(255,255,255,.15)',fontSize:16,fontWeight:800,color:i===2?C.lavender:C.pale}}>{v}</div>)}</div>
          <div style={{marginTop:32,fontSize:19,color:C.muted}}>Cards · Local rails · Stablecoins</div>
        </>}
        {kind==='payout' && <>
          <div style={{fontSize:18,color:C.muted,letterSpacing:'.14em'}}>GLOBAL PAYOUT ROUTING</div>
          <div style={{fontSize:64,fontWeight:800,marginTop:28}}>Dispatched<span style={{color:C.mint}}> ✓</span></div>
          <div style={{marginTop:26,display:'flex',flexDirection:'column',gap:18}}>{[['London, UK','GBP','Paid'],['Toronto, CA','CAD','Paid'],['Dubai, UAE','AED','Paid']].map((r,i)=><div key={r[0]} style={{display:'flex',justifyContent:'space-between',padding:'18px 20px',borderRadius:18,background:'rgba(255,255,255,.08)',fontSize:19}}><span>{r[0]}</span><b>{r[1]}</b><span style={{color:C.mint}}>{r[2]}</span></div>)}</div>
        </>}
        {kind==='card' && <>
          <div style={{fontSize:18,color:C.muted,letterSpacing:'.14em'}}>NUVION GLOBAL CARD</div>
          <div style={{position:'relative',margin:'45px auto 0',width:450,height:265,borderRadius:28,padding:28,boxSizing:'border-box',background:'linear-gradient(135deg,#9A55E8,#32124F 60%,#CB4930)',boxShadow:'0 25px 60px rgba(141,60,253,.4)',transform:'rotate(-7deg)'}}><div style={{fontSize:25,fontWeight:800}}>nuvion</div><div style={{position:'absolute',left:28,bottom:66,fontSize:22,letterSpacing:'.22em'}}>••••  ••••  ••••  2048</div><div style={{position:'absolute',right:28,bottom:24,fontSize:18,fontWeight:800}}>VISA</div><div style={{position:'absolute',right:28,top:28,fontSize:28}}>◉</div></div>
          <div style={{marginTop:42,fontSize:20,color:C.muted,textAlign:'center'}}>Virtual & physical · Global spending control</div>
        </>}
      </GlassCard>
    </div>
  </div>;
};

export const SceneCapabilities: React.FC = () => {
  const f = useCurrentFrame();
  const drift = Math.sin(f/28)*16;
  const titles = [
    {title:'MOVE BETWEEN\nCURRENCIES.',sub:'Manage global balances and move between major currencies from one connected account.',kind:'fx'},
    {title:'ACCEPT PAYMENTS\nWORLDWIDE.',sub:'Reach customers across markets with cards, local payment rails and stablecoin infrastructure.',kind:'pay'},
    {title:'PAY ACROSS\nBORDERS.',sub:'Send money to people and businesses around the world through local payout networks.',kind:'payout'},
    {title:'BUILD FINANCIAL\nEXPERIENCES.',sub:'Bring global financial experiences together with infrastructure designed to scale.',kind:'card'},
  ];
  return <AbsoluteFill style={{overflow:'hidden'}}>
    <Ambient accent={C.violet}/>
    <div style={{position:'absolute',inset:0,transform:`translateY(${drift}px)`}}>
      {titles.map((item,i)=><Capability key={item.kind} {...item} index={i}/>) }
    </div>
    <div style={{position:'absolute',right:70,bottom:55,fontSize:15,letterSpacing:'.22em',color:'#9C8EAE'}}>NUVION  /  GLOBAL FINANCIAL INFRASTRUCTURE</div>
  </AbsoluteFill>;
};
