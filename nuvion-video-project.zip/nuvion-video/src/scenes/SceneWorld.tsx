import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame} from 'remotion';
import {Ambient, clamp, Eyebrow, Reveal} from './shared';
import {C, FONT_HEAD} from '../theme';

export const SceneWorld: React.FC = () => {
  const f = useCurrentFrame();
  const spin = f * 0.22;
  const zoom = interpolate(f, [0, 209], [1, 1.16], clamp);
  const first = interpolate(f, [0, 18, 92], [0, 1, 0], clamp);
  const second = interpolate(f, [103, 124, 200], [0, 1, 1], clamp);
  return <AbsoluteFill style={{overflow: 'hidden'}}>
    <Ambient accent={C.violet} />
    <div style={{position: 'absolute', width: 780, height: 780, left: 1010, top: 150, transform: `translate(-50%, -50%) scale(${zoom}) rotate(${spin}deg)`, borderRadius: '50%', border: '1px solid rgba(196,163,211,.32)', boxShadow: '0 0 80px rgba(141,60,253,.16), inset 0 0 70px rgba(141,60,253,.1)'}}>
      {[0,1,2,3,4].map((v) => <div key={v} style={{position: 'absolute', inset: 50 + v * 55, border: '1px solid rgba(196,163,211,.18)', borderRadius: '50%', transform: `rotateX(${58 + v * 4}deg) rotateY(${v * 18}deg)`}} />)}
      <svg viewBox="0 0 780 780" style={{position: 'absolute', inset: 0, width: '100%', height: '100%'}}><ellipse cx="390" cy="390" rx="320" ry="125" fill="none" stroke={C.lilac} strokeOpacity=".55" strokeWidth="2" transform="rotate(-28 390 390)"/><ellipse cx="390" cy="390" rx="320" ry="125" fill="none" stroke={C.lavender} strokeOpacity=".4" strokeWidth="2" transform="rotate(48 390 390)"/><path d="M90 390H690M390 70V710" stroke={C.lavender} strokeOpacity=".22" strokeDasharray="6 14"/></svg>
      <div style={{position: 'absolute', width: 22, height: 22, borderRadius: '50%', background: C.pale, boxShadow: `0 0 34px ${C.lavender}`, left: 135, top: 205}} />
      <div style={{position: 'absolute', width: 16, height: 16, borderRadius: '50%', background: C.coral, boxShadow: `0 0 28px ${C.coral}`, right: 125, bottom: 185}} />
    </div>
    <div style={{position: 'absolute', left: 180, top: 235, width: 1000}}>
      <div style={{opacity: first, transform: `translateX(${(1-first)*-40}px)`}}><Eyebrow>Global finance, reimagined</Eyebrow><div style={{fontFamily: FONT_HEAD, fontSize: 112, lineHeight: .98, letterSpacing: '-.065em', fontWeight: 700, marginTop: 28}}>THE WORLD<br/><span style={{color: C.lavender}}>IS GLOBAL.</span></div></div>
      <div style={{position: 'absolute', left: 0, top: 0, opacity: second, transform: `translateX(${(1-second)*50}px)`}}><Eyebrow>Your money should be too</Eyebrow><div style={{fontFamily: FONT_HEAD, fontSize: 102, lineHeight: 1.0, letterSpacing: '-.065em', fontWeight: 700, marginTop: 28}}>YOUR MONEY<br/><span style={{color: C.lavender}}>SHOULD BE TOO.</span></div></div>
    </div>
    <div style={{position: 'absolute', right: 92, bottom: 70, fontSize: 16, letterSpacing: '.24em', color: '#B7A9C9'}}>A WORLD WITHOUT FINANCIAL BORDERS</div>
  </AbsoluteFill>;
};
