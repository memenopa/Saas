import {registerRoot} from 'remotion';
import {Root} from './Root';
import './global.css';

registerRoot(Root);
