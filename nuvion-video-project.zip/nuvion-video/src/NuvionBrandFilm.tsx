import React from 'react';
import {AbsoluteFill, Audio, Sequence, staticFile} from 'remotion';
import {C} from './theme';
import {SceneWorld} from './scenes/SceneWorld';
import {SceneMeet} from './scenes/SceneMeet';
import {SceneEcosystem} from './scenes/SceneEcosystem';
import {SceneCapabilities} from './scenes/SceneCapabilities';
import {SceneInfrastructure} from './scenes/SceneInfrastructure';
import {SceneOutro} from './scenes/SceneOutro';

export const NuvionBrandFilm: React.FC = () => (
  <AbsoluteFill style={{backgroundColor: C.ink, color: C.white, fontFamily: 'Inter, Arial, sans-serif'}}>
    <Sequence from={0} durationInFrames={209}><SceneWorld /></Sequence>
    <Sequence from={209} durationInFrames={85}><SceneMeet /></Sequence>
    <Sequence from={294} durationInFrames={304}><SceneEcosystem /></Sequence>
    <Sequence from={598} durationInFrames={591}><SceneCapabilities /></Sequence>
    <Sequence from={1189} durationInFrames={242}><SceneInfrastructure /></Sequence>
    <Sequence from={1431} durationInFrames={156}><SceneOutro /></Sequence>
    <Audio src={staticFile('audio/nuvion-voiceover.mp3')} volume={1} />
  </AbsoluteFill>
);
