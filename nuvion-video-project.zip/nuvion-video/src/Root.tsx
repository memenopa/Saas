import React from 'react';
import {Composition} from 'remotion';
import {NuvionBrandFilm} from './NuvionBrandFilm';

export const Root: React.FC = () => (
  <>
    <Composition
      id="NuvionBrandFilm"
      component={NuvionBrandFilm}
      durationInFrames={1587}
      width={1920}
      height={1080}
      fps={60}
      defaultProps={{}}
    />
  </>
);
