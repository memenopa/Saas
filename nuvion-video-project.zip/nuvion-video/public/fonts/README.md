# Brand font

The composition is configured to use `Nuvion Sans` for headlines. The font binary was not available from the public website source used for this build, so no font file is redistributed here.

If you have a licensed Nuvion Sans webfont, place it here as:

`public/fonts/NuvionSans.woff2`

The CSS will load it automatically. Until then, the composition falls back to Inter / Arial. Body copy uses a clean neo-grotesque system stack.
