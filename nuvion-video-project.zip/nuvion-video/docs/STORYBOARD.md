# Nuvion — 16:9 brand film storyboard

**Master:** 1920 × 1080, 60 fps, 1,587 frames, 26.45 seconds  
**Voiceover:** supplied ElevenLabs MP3 (26.436 seconds)  
**Format:** YouTube landscape 16:9  
**Motion rule:** no static shots; every scene uses frame-driven movement, camera drift, rotating/orbiting elements, kinetic typography, or animated UI.

## Timed sequence

| Time | Voiceover | Visual choreography |
|---|---|---|
| 00:00–00:03.49 | “The world is global. Your money should be too.” | Deep plum space; an illuminated global sphere rotates behind split kinetic headlines. The second statement sweeps in with a lateral camera push. |
| 00:03.49–00:04.91 | “Meet Nuvion.” | Orbital rings converge; the Nuvion wordmark springs into the center with a dimensional tilt and light bloom. |
| 00:04.91–00:09.98 | “One financial ecosystem connecting global accounts, payments, payouts and cards.” | Four glass UI modules orbit a central Nuvion hub. Connection paths draw on; each module floats and pulses independently. |
| 00:09.98–00:19.83 | “Move between currencies. Accept payments worldwide. Pay across borders. And build financial experiences with infrastructure designed to scale.” | Four 2.5D dashboard match-cuts: currency conversion, payment settlement, multi-market payout routing, and global card issuing. Each panel moves in with a perspective tilt and exits with a lateral push. |
| 00:19.83–00:23.87 | “Powered by intelligent technology. Built for a world without limits.” | Concentric intelligence rings orbit around Nuvion IQ; an illuminated intelligence core expands. The limitless statement rises in as the camera pushes forward. |
| 00:23.87–00:26.45 | “Nuvion. Go borderless.” | Four-point sparkle scales into a portal; the logo and final tagline resolve in a clean centered lockup with a moving orbital halo. |

## Voiceover timing notes

Timing was estimated against the supplied 26.436-second audio using its audible phrase pauses. The actual audio is included and placed on the composition timeline from frame 0. Scene boundaries are aligned to the pauses at approximately 3.49s, 4.91s, 9.98s, 19.83s, and 23.87s.

## Product truth used in the visuals

The official Nuvion site describes global / multi-currency accounts, stablecoin rails, global card issuing, market access, global payouts, and Nuvion IQ. The visuals use these as interface metaphors; the dashboard values and account names are illustrative UI art, not screenshots or claims about live account data.

## Brand fidelity notes

- Headline font stack: `Nuvion Sans`, then Inter / Arial fallback.
- Body font stack: Inter / Helvetica Neue / Arial.
- The actual Nuvion Sans font binary was not publicly available in the source materials. Add a licensed `NuvionSans.woff2` to `public/fonts/` for exact typography.
- The color direction is an interpretation of the vivid, expansive Nuvion brand identity and publicly surfaced palette references; it is not represented as an official CSS token export.
- The central N-mark / wordmark in this code is a temporary vector treatment. Replace `Wordmark` in `src/scenes/shared.tsx` with official vector artwork if a brand-approved SVG becomes available.
