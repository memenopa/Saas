# Build notes

- Composition length is 1,587 frames at 60 fps (26.45 seconds), matching the supplied 26.4359-second voiceover to the nearest frame.
- Scene boundaries follow the main phrase pauses measured from the supplied audio waveform.
- The source has been checked for TypeScript/TSX syntax diagnostics. Full type-checking and rendering require the project dependencies; installation could not complete in this environment because network access was unavailable.
- In Codespaces: run `npm install`, then `npm run start`. For final MP4 export: `npm run render`.
- If your Codespace uses a different forwarded port, open the port shown by the Remotion Studio process.
