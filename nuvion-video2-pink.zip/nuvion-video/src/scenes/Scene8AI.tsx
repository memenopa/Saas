import React from 'react';
import {AbsoluteFill, random, useCurrentFrame} from 'remotion';
import {Backdrop} from '../components/Backdrop';
import {Camera} from '../components/Camera';
import {Row, Word} from '../components/Word';
import {Sparkle} from '../components/Sparkle';
import {C, SCENES} from '../lib/constants';
import {local, pop} from '../lib/motion';

const S = SCENES.ai.from;
const L = (a: number) => local(a, S);
const N = 34;
const NODES = new Array(N).fill(0).map((_, i) => ({
  x: 80 + random(`nx${i}`) * 1760,
  y: 60 + random(`ny${i}`) * 960,
  r: 18 + random(`nr${i}`) * 50,
  sp: 0.03 + random(`ns${i}`) * 0.05,
  ph: random(`np${i}`) * 6.28,
}));

export const Scene8AI: React.FC = () => {
  const frame = useCurrentFrame();
  const intro = pop(frame, 0);
  const pos = NODES.map((n) => ({
    x: n.x + Math.cos(frame * n.sp + n.ph) * n.r,
    y: n.y + Math.sin(frame * n.sp * 1.2 + n.ph) * n.r,
  }));
  const links: {a: number; b: number; d: number}[] = [];
  for (let i = 0; i < N; i++) {
    for (let j = i + 1; j < N; j++) {
      const d = Math.hypot(pos[i].x - pos[j].x, pos[i].y - pos[j].y);
      if (d < 340) links.push({a: i, b: j, d});
    }
  }
  return (
    <AbsoluteFill>
      <Backdrop mode="dark" particles={14} />
      <Camera zoom={0.07} amp={1.2}>
        <div style={{position: 'absolute', left: 960 - 330, top: 540 - 330, opacity: 0.55 * intro}}>
          <Sparkle size={660} rotate={frame * 1.2} scale={0.92 + Math.sin(frame / 8) * 0.06} grad />
        </div>
        <svg width={1920} height={1080} style={{position: 'absolute', inset: 0, opacity: intro}}>
          {links.map((l, i) => {
            const t = (frame * 0.03 + i * 0.173) % 1;
            const x = pos[l.a].x + (pos[l.b].x - pos[l.a].x) * t;
            const y = pos[l.a].y + (pos[l.b].y - pos[l.a].y) * t;
            return (
              <g key={i}>
                <line x1={pos[l.a].x} y1={pos[l.a].y} x2={pos[l.b].x} y2={pos[l.b].y} stroke={C.coral} strokeWidth={2} opacity={(1 - l.d / 340) * 0.6} />
                <circle cx={x} cy={y} r={5} fill={C.peach} opacity={0.9} />
              </g>
            );
          })}
          {pos.map((p, i) => (
            <circle key={i} cx={p.x} cy={p.y} r={7 + Math.sin(frame / 6 + i) * 2.5} fill={C.ember} />
          ))}
        </svg>
        <div style={{position: 'absolute', inset: 0, background: 'radial-gradient(ellipse 52% 34% at 50% 50%, rgba(21,3,9,0.88) 0%, rgba(21,3,9,0.55) 60%, transparent 100%)'}} />
        <div style={{position: 'absolute', inset: 0, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center'}}>
          <Row gap={30}>
            <Word at={L(19.9)} size={92} color={C.blush}>Powered</Word>
            <Word at={L(20.2)} size={92} color={C.blush}>by</Word>
          </Row>
          <Word at={L(20.45)} size={170} grad>intelligent</Word>
          <Word at={L(21.0)} size={170} grad>technology.</Word>
        </div>
      </Camera>
    </AbsoluteFill>
  );
};
