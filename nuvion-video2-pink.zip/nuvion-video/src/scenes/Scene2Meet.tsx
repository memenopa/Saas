import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {Backdrop} from '../components/Backdrop';
import {Camera} from '../components/Camera';
import {Logo} from '../components/Logo';
import {Word} from '../components/Word';
import {ZCloud, CloudItem} from '../components/ZCloud';
import {C, FPS, SCENES} from '../lib/constants';
import {pop, ramp} from '../lib/motion';

const ITEMS: CloudItem[] = [
  {text: 'accounts', z: 1.35, a0: 0.3, rx: 760, ry: 380, speed: 0.022},
  {text: 'USD', z: 0.65, a0: 1.5, rx: 700, ry: 330, speed: -0.03},
  {text: 'payments', z: 0.8, a0: 2.6, rx: 820, ry: 400, speed: 0.026},
  {text: 'EUR', z: 1.3, a0: 3.7, rx: 640, ry: 360, speed: -0.024},
  {text: 'payouts', z: 0.7, a0: 4.6, rx: 780, ry: 340, speed: 0.03},
  {text: 'GBP', z: 1.1, a0: 5.5, rx: 700, ry: 410, speed: -0.02},
  {text: 'cards', z: 1.4, a0: 0.9, rx: 840, ry: 360, speed: -0.028},
  {text: 'NGN', z: 0.6, a0: 2.1, rx: 600, ry: 300, speed: 0.034},
];

export const Scene2Meet: React.FC = () => {
  const frame = useCurrentFrame();
  const logoP = pop(frame, 5);
  const shimmer = ramp(frame, 14, 44, 0, 1);
  const glow = 1 + Math.sin(frame / 6) * 0.06;
  return (
    <AbsoluteFill>
      <Backdrop mode="dark" particles={30} />
      <Camera zoom={0.08} amp={1.2}>
        <ZCloud items={ITEMS} layer="back" start={4} />
        <div
          style={{
            position: 'absolute',
            left: 960 - 700,
            top: 560 - 700,
            width: 1400,
            height: 1400,
            borderRadius: '50%',
            background: `radial-gradient(circle, rgba(232,38,95,0.42) 0%, transparent 60%)`,
            transform: `scale(${logoP * glow})`,
          }}
        />
        <div style={{position: 'absolute', left: 0, right: 0, top: 300, textAlign: 'center'}}>
          <Word at={0} size={78} color={C.peach} weight={700} spacing="0.02em">Meet</Word>
        </div>
        <div
          style={{
            position: 'absolute',
            left: 960 - 560,
            top: 560 - 1120 / 5.09 / 2,
            transform: `scale(${0.55 + logoP * 0.45}) rotate(${(1 - logoP) * -5}deg)`,
            filter: `blur(${(1 - logoP) * 14}px)`,
            opacity: logoP,
          }}
        >
          <Logo width={1120} variant="light" shimmer={shimmer} />
        </div>
        <ZCloud items={ITEMS} layer="front" start={4} />
      </Camera>
    </AbsoluteFill>
  );
};
