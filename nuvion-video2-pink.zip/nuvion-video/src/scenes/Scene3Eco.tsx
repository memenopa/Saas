import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {Backdrop} from '../components/Backdrop';
import {Camera} from '../components/Camera';
import {Coin, IconKind, NavPill} from '../components/Pill';
import {Row, Word} from '../components/Word';
import {C, CURRENCIES, FONT_HEAD, GRAD, SCENES} from '../lib/constants';
import {local, pop, SOFT, ramp} from '../lib/motion';
import {sec} from '../lib/constants';

const S = SCENES.eco.from;
const L = (a: number) => local(a, S);
const CX = 960;
const CY = 640;
const RX = 620;
const RY = 260;

const PILLS: {label: string; kind: IconKind; at: number; base: number}[] = [
  {label: 'Global accounts', kind: 'accounts', at: 7.0, base: Math.PI},
  {label: 'Payments', kind: 'payments', at: 8.0, base: -Math.PI / 2},
  {label: 'Payouts', kind: 'payouts', at: 8.7, base: 0},
  {label: 'Cards', kind: 'cards', at: 9.35, base: Math.PI / 2},
];

export const Scene3Eco: React.FC = () => {
  const frame = useCurrentFrame();
  const hubP = pop(frame, L(5.2));
  const spin = frame * 0.012;
  return (
    <AbsoluteFill>
      <Backdrop mode="light" />
      <Camera zoom={0.05} amp={0.9}>
        {/* concentric pulse rings on the orbit plane */}
        <svg width={1920} height={1080} style={{position: 'absolute', inset: 0}}>
          {[0, 1, 2, 3].map((i) => {
            const ph = (frame / 54 + i / 4) % 1;
            const r = 130 + ph * 700;
            return (
              <ellipse key={i} cx={CX} cy={CY} rx={r} ry={r * (RY / RX)} fill="none" stroke={C.ember} strokeWidth={3} opacity={(1 - ph) * 0.5 * hubP} />
            );
          })}
          <ellipse cx={CX} cy={CY} rx={RX} ry={RY} fill="none" stroke={C.coral} strokeWidth={2} strokeDasharray="10 16" strokeDashoffset={-frame * 3} opacity={0.5 * hubP} />
        </svg>

        {/* headline */}
        <div style={{position: 'absolute', left: 0, right: 0, top: 70, display: 'flex', justifyContent: 'center'}}>
          <Row gap={30}>
            <Word at={L(5.0)} size={104}>One</Word>
            <Word at={L(5.3)} size={104}>financial</Word>
            <Word at={L(5.75)} size={104} grad>ecosystem</Word>
          </Row>
        </div>

        {/* orbiting currency badges, opposite direction */}
        {CURRENCIES.concat(CURRENCIES).map((g, i) => {
          const a = -frame * 0.02 + (i * Math.PI * 2) / 10;
          const x = CX + Math.cos(a) * RX * 1.18;
          const y = CY + Math.sin(a) * RY * 1.18;
          const d = 0.6 + 0.3 * ((Math.sin(a) + 1) / 2);
          return (
            <div key={i} style={{position: 'absolute', left: x - 28, top: y - 28, transform: `scale(${d * ramp(frame, L(5.4) + i * 2, L(5.4) + i * 2 + 10)})`, opacity: 0.85}}>
              <Coin glyph={g} size={56} />
            </div>
          );
        })}

        {/* hub */}
        <div
          style={{
            position: 'absolute',
            left: CX - 100,
            top: CY - 100,
            width: 200,
            height: 200,
            borderRadius: '50%',
            background: GRAD,
            boxShadow: '0 0 90px rgba(232,38,95,0.6), inset 0 -10px 24px rgba(0,0,0,0.15)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            transform: `scale(${hubP * (1 + Math.sin(frame / 7) * 0.04)})`,
            zIndex: 5,
          }}
        >
          <span style={{fontFamily: FONT_HEAD, fontWeight: 800, fontSize: 150, color: '#fff', letterSpacing: '-0.05em', marginTop: -14}}>n</span>
        </div>

        {/* converging pills */}
        {PILLS.map((p) => {
          const pr = pop(frame, L(p.at), SOFT);
          const a = p.base + spin;
          const k = 1 + (1 - pr) * 1.7;
          const depth = 0.86 + 0.14 * ((Math.sin(a) + 1) / 2);
          const x = CX + Math.cos(a) * RX * k;
          const y = CY + Math.sin(a) * RY * k;
          return (
            <div
              key={p.label}
              style={{
                position: 'absolute',
                left: x - 190,
                top: y - 56,
                opacity: Math.min(1, pr * 1.8),
                transform: `scale(${depth * (0.9 + pr * 0.1)})`,
                zIndex: 10 + Math.round(Math.sin(a) * 5),
              }}
            >
              <NavPill label={p.label} kind={p.kind} width={380} />
            </div>
          );
        })}
      </Camera>
    </AbsoluteFill>
  );
};
