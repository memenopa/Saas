import React from 'react';
import {staticFile} from 'remotion';

export const LOGO_ASPECT = 1508 / 296;

/** Nuvion wordmark with an optional moving light sweep (`shimmer` 0..1). */
export const Logo: React.FC<{
  width: number;
  variant: 'dark' | 'light';
  shimmer?: number;
  style?: React.CSSProperties;
}> = ({width, variant, shimmer, style}) => {
  const src = staticFile(variant === 'dark' ? 'logo-dark.png' : 'logo-light.png');
  const height = width / LOGO_ASPECT;
  return (
    <div style={{position: 'relative', width, height, ...style}}>
      <img src={src} style={{width, height, display: 'block'}} />
      {shimmer !== undefined && shimmer > 0 && shimmer < 1 && (
        <div
          style={{
            position: 'absolute',
            inset: 0,
            WebkitMaskImage: `url(${src})`,
            maskImage: `url(${src})`,
            WebkitMaskSize: '100% 100%',
            maskSize: '100% 100%',
            backgroundImage: 'linear-gradient(105deg, transparent 35%, #FF5C8A 48%, #FFD6E2 52%, transparent 65%)',
            backgroundSize: '250% 100%',
            backgroundPosition: `${120 - shimmer * 140}% 0`,
            backgroundRepeat: 'no-repeat',
          }}
        />
      )}
    </div>
  );
};
