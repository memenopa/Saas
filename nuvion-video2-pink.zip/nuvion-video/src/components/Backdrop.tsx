import React from 'react';
import {AbsoluteFill, random, useCurrentFrame} from 'remotion';
import {C, FPS, HEIGHT, WIDTH} from '../lib/constants';
import {mod} from '../lib/motion';

export const Backdrop: React.FC<{mode: 'light' | 'dark'; particles?: number}> = ({
  mode,
  particles = 26,
}) => {
  const frame = useCurrentFrame();
  const t = frame / FPS;
  const light = mode === 'light';

  const base = light
    ? `linear-gradient(160deg, #FFF7FA 0%, ${C.blush} 55%, #FADDE6 100%)`
    : `radial-gradient(120% 90% at 50% 0%, ${C.night2} 0%, ${C.night} 60%, #0A0105 100%)`;

  const blooms = light
    ? [
        {c: C.peach, o: 0.6},
        {c: '#FFC9D9', o: 0.7},
        {c: C.coral, o: 0.22},
      ]
    : [
        {c: C.ember, o: 0.3},
        {c: '#8C1238', o: 0.5},
        {c: C.coral, o: 0.18},
      ];

  return (
    <AbsoluteFill style={{background: base, overflow: 'hidden'}}>
      {blooms.map((b, i) => {
        const x = WIDTH / 2 + 560 * Math.sin(t * 0.55 + i * 2.1);
        const y = HEIGHT / 2 + 320 * Math.cos(t * 0.42 + i * 1.7);
        const size = 1200 - i * 160;
        return (
          <div
            key={i}
            style={{
              position: 'absolute',
              left: x - size / 2,
              top: y - size / 2,
              width: size,
              height: size,
              borderRadius: '50%',
              background: `radial-gradient(circle, ${b.c} 0%, transparent 65%)`,
              opacity: b.o,
            }}
          />
        );
      })}
      {new Array(particles).fill(0).map((_, i) => {
        const x0 = random(`bx${i}`) * WIDTH;
        const y0 = random(`by${i}`) * (HEIGHT + 200);
        const speed = 0.5 + random(`bs${i}`) * 1.4;
        const size = 4 + random(`bz${i}`) * 10;
        const y = HEIGHT + 100 - mod(y0 + frame * speed * 2.2, HEIGHT + 200);
        const x = x0 + Math.sin(frame / 40 + i) * 26;
        return (
          <div
            key={i}
            style={{
              position: 'absolute',
              left: x,
              top: y,
              width: size,
              height: size,
              borderRadius: '50%',
              background: light ? C.ember : C.peach,
              opacity: light ? 0.18 : 0.28,
            }}
          />
        );
      })}
    </AbsoluteFill>
  );
};
