import React from 'react';
import {C, FONT_BODY, FONT_HEAD, GRAD} from '../lib/constants';

export type IconKind = 'accounts' | 'payments' | 'payouts' | 'cards';

const PATHS: Record<IconKind, string> = {
  accounts: 'M3 10l9-6 9 6M5 10v8M9 10v8M15 10v8M19 10v8M3 20h18',
  payments: 'M12 3v12m0 0l-4-4m4 4l4-4M4 19h16',
  payouts: 'M12 21V9m0 0l-4 4m4-4l4 4M4 5h16',
  cards: 'M3 6h18v12H3z M3 10h18 M7 15h4',
};

export const Icon: React.FC<{kind: IconKind; size?: number}> = ({kind, size = 32}) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
    <path d={PATHS[kind]} />
  </svg>
);

export const glass = (mode: 'light' | 'dark'): React.CSSProperties => ({
  background: mode === 'light' ? 'rgba(255,255,255,0.74)' : 'rgba(255,255,255,0.08)',
  border: `1px solid ${mode === 'light' ? 'rgba(255,255,255,0.9)' : 'rgba(255,179,202,0.28)'}`,
  backdropFilter: 'blur(16px)',
  WebkitBackdropFilter: 'blur(16px)',
  boxShadow: '0 20px 50px rgba(232,38,95,0.25)',
});

/** Skeleton pill: gradient icon + label + two rounded bars. */
export const NavPill: React.FC<{
  label: string;
  kind: IconKind;
  mode?: 'light' | 'dark';
  width?: number;
}> = ({label, kind, mode = 'light', width = 360}) => (
  <div
    style={{
      ...glass(mode),
      width,
      height: 112,
      borderRadius: 36,
      display: 'flex',
      alignItems: 'center',
      gap: 22,
      padding: '0 26px',
      boxSizing: 'border-box',
    }}
  >
    <div
      style={{
        width: 68,
        height: 68,
        borderRadius: 24,
        background: GRAD,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        boxShadow: '0 10px 26px rgba(232,38,95,0.45)',
        flexShrink: 0,
      }}
    >
      <Icon kind={kind} />
    </div>
    <div style={{flex: 1}}>
      <div style={{fontFamily: FONT_HEAD, fontWeight: 700, fontSize: 34, letterSpacing: '-0.03em', color: mode === 'light' ? C.ink : C.blush}}>
        {label}
      </div>
      <div style={{height: 12, width: '72%', borderRadius: 999, background: C.peach, opacity: 0.8, marginTop: 10}} />
      <div style={{height: 12, width: '44%', borderRadius: 999, background: C.peach, opacity: 0.45, marginTop: 8}} />
    </div>
  </div>
);

export const Coin: React.FC<{glyph: string; size?: number; scaleX?: number; dark?: boolean}> = ({
  glyph,
  size = 120,
  scaleX = 1,
  dark = false,
}) => (
  <div
    style={{
      width: size,
      height: size,
      borderRadius: '50%',
      background: dark ? 'rgba(255,255,255,0.1)' : GRAD,
      border: dark ? `2px solid ${C.coral}` : '2px solid rgba(255,255,255,0.7)',
      boxShadow: '0 16px 40px rgba(232,38,95,0.4), inset 0 -8px 18px rgba(0,0,0,0.12)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: dark ? C.peach : '#fff',
      fontFamily: FONT_BODY,
      fontWeight: 700,
      fontSize: size * 0.5,
      transform: `scaleX(${scaleX})`,
    }}
  >
    {glyph}
  </div>
);
