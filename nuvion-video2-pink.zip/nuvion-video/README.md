# Nuvion Launch Video (Remotion)

A 27.5 s, 1920x1080 SaaS launch video synced to the ElevenLabs voiceover in `public/voiceover.mp3`.
Style follows `SaaS_Video_Style_Master_Prompt.md`: kinetic type, light/dark polarity, glass UI, 2.5D tilt,
orbital convergence, sparkle portal. Every scene animates continuously (camera drift, orbits, particles), so no shot is static.

## Run in GitHub Codespaces
```bash
npm install          # automatic if you use the included devcontainer
npm run dev          # opens Remotion Studio on port 3000 (Codespaces forwards it)
npm run render       # out/nuvion-launch.mp4, render concurrency fixed at 2
npm run render:preview   # half-res, faster check render
```
Concurrency is set to 2 in both `remotion.config.ts` and the npm scripts.

## Where things live
- `src/lib/constants.ts`: FPS, colors, fonts, **scene timings in seconds** (matched to voiceover pauses)
- `src/scenes/`: one file per voiceover beat (Scene1Hook ... Scene11Tag)
- `src/components/`: Backdrop, Camera, Reveal (scene transitions), Word (blur swap), Globe, Dashboard, etc.
- `public/`: voiceover, `logo-dark.png`, `logo-light.png`, `fonts/`

## Brand notes
- Colors follow the Nuvion brand pink (`#E8265F`) with pink-tinted ink `#2B0612` and blush `#FDEFF3` neutrals; coral/peach are lighter tints of the pink. Edit `C` in `constants.ts` if Nuvion's official palette differs.
- Headline font: drop `NuvionSans.woff2` (or .otf/.ttf) into `public/fonts/`. Until then Outfit ExtraBold is the stand-in. Body font: Inter.
- The logo PNGs were cut from the supplied JPEG and upscaled. Replace `public/logo-dark.png` / `logo-light.png` with official transparent files (keep an aspect ratio near 5.09:1, or update `LOGO_ASPECT` in `Logo.tsx`).
- Dashboard amounts, city names and currencies are illustrative demo data.

## Notes
- FPS is 30. Change `FPS` in `constants.ts` for 60; all timings are in seconds and will follow.
- First render downloads Chrome Headless Shell and Google Fonts, so Codespaces needs internet (it has it by default).
